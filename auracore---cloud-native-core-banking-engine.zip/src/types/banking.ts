export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'CHF' | 'JPY' | 'CAD' | 'SGD';

export type AccountType =
  | 'RETAIL_CHECKING'
  | 'HIGH_YIELD_SAVINGS'
  | 'COMMERCIAL_TREASURY'
  | 'SME_OVERDRAFT_CREDIT'
  | 'CENTRAL_BANK_NOSTRO'
  | 'SETTLEMENT_CLEARING_FLOAT'
  | 'INTERNAL_FEES_REVENUE'
  | 'INTEREST_EXPENSE_POOL';

export interface AccountBalancePartitions {
  available: number;
  pendingHold: number;
  lienCollateral: number;
  accruedInterest: number;
  ledgerTotal: number;
}

export interface BankAccount {
  id: string;
  accountNumber: string;
  iban: string;
  holderName: string;
  customerId: string;
  type: AccountType;
  currency: CurrencyCode;
  partitions: AccountBalancePartitions;
  status: 'ACTIVE' | 'FROZEN' | 'DORMANT' | 'RESTRICTED';
  productId: string;
  openedAt: string;
  branchCode: string;
}

export interface PostingLeg {
  accountId: string;
  accountName: string;
  type: 'DEBIT' | 'CREDIT';
  amount: number;
  currency: CurrencyCode;
  partitionTarget?: 'available' | 'pendingHold' | 'lienCollateral' | 'accruedInterest';
}

export interface JournalEntry {
  id: string;
  sequenceNumber: number;
  timestamp: string;
  effectiveDate: string;
  description: string;
  referenceId: string;
  postingType:
    | 'CUSTOMER_TRANSFER'
    | 'PAYMENT_SETTLEMENT'
    | 'INTEREST_ACCRUAL'
    | 'FEE_ASSESSMENT'
    | 'HOLD_AUTHORIZATION'
    | 'HOLD_RELEASE'
    | 'DEPOSIT_CREDIT'
    | 'WITHDRAWAL_DEBIT';
  legs: PostingLeg[];
  totalDebit: number;
  totalCredit: number;
  balanced: boolean;
  status: 'POSTED' | 'REVERSED';
  settlementRail?: string;
  contractRuleTriggered?: string;
}

export interface SmartContractProduct {
  id: string;
  name: string;
  category: 'RETAIL' | 'COMMERCIAL' | 'TREASURY' | 'WEALTH';
  version: string;
  description: string;
  pythonContractCode: string;
  parameters: {
    interestRatePercent: number;
    interestCalculationFrequency: 'DAILY' | 'MONTHLY' | 'ANNUAL';
    tierThresholdAmount: number;
    tierBonusRatePercent: number;
    overdraftLimit: number;
    overdraftFeeDaily: number;
    gracePeriodDays: number;
    dormancyThresholdDays: number;
  };
  activeAccountsCount: number;
  totalManagedBalance: number;
  lastAccrualRun: string;
  status: 'ACTIVE' | 'DRAFT' | 'SUPERSEDED';
}

export type PaymentRail = 'FedNow' | 'SEPA_Instant' | 'FPS_UK' | 'SWIFT_gpi';

export type PaymentStatus =
  | 'SETTLED'
  | 'CLEARING'
  | 'PENDING_SANCTIONS'
  | 'REJECTED'
  | 'REVERSED';

export interface PaymentTransaction {
  id: string;
  endToEndId: string;
  uetr: string; // Unique End-to-end Transaction Reference for ISO 20022
  messageType: 'pacs.008.001.10' | 'pacs.002.001.12' | 'pain.001.001.11' | 'camt.053.001.10';
  rail: PaymentRail;
  senderAccountId: string;
  senderName: string;
  senderIban: string;
  receiverAccountId: string;
  receiverName: string;
  receiverIban: string;
  receiverBic: string;
  amount: number;
  currency: CurrencyCode;
  remittanceInformation: string;
  status: PaymentStatus;
  sanctionCheckScore: number; // 0-100 (0 = clean, >80 = flag)
  timestamp: string;
  settlementDurationMs: number;
  isoXmlPayload: string;
}

export interface CustomerKycRecord {
  id: string;
  customerType: 'RETAIL_INDIVIDUAL' | 'COMMERCIAL_CORPORATE';
  legalName: string;
  taxIdentifier: string; // SSN or EIN/VAT
  countryOfResidence: string;
  riskTier: 'LOW' | 'MEDIUM' | 'HIGH';
  kycStatus: 'VERIFIED' | 'PENDING_DOCUMENTATION' | 'ENHANCED_DUE_DILIGENCE';
  pepSanctionMatch: boolean;
  onboardedAt: string;
  assignedAccounts: string[];
  totalDeposits: number;
  documentType: 'PASSPORT' | 'DRIVERS_LICENSE' | 'ARTICLES_OF_INCORPORATION';
  documentNumber: string;
}

export interface MigrationComparisonMetric {
  dimension: string;
  auraCore: string;
  thoughtMachineVault: string;
  temenosTransact: string;
  impactAdvantage: string;
}

export interface ShadowRunTransaction {
  id: string;
  description: string;
  amount: number;
  currency: CurrencyCode;
  legacyStatus: 'PROCESSING_BATCH' | 'COMPLETED_END_OF_DAY' | 'QUEUED';
  legacyLatencySeconds: number;
  auraCoreStatus: 'SETTLED_REALTIME';
  auraCoreLatencyMs: number;
  deltaMismatch: boolean;
}
