import React, { useState } from 'react';
import {
  GitCompare,
  Zap,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Play,
  RotateCcw,
  Layers,
  ArrowRight,
  TrendingDown,
  Building,
} from 'lucide-react';
import { MIGRATION_BENCHMARKS, INITIAL_SHADOW_RUN_TXS } from '../data/mockData';
import { ShadowRunTransaction } from '../types/banking';

export const MigrationStudio: React.FC = () => {
  const [shadowTxs, setShadowTxs] = useState<ShadowRunTransaction[]>(INITIAL_SHADOW_RUN_TXS);
  const [isRunningShadowReplay, setIsRunningShadowReplay] = useState(false);
  const [reconciledCount, setReconciledCount] = useState(INITIAL_SHADOW_RUN_TXS.length);
  const [activeTab, setActiveTab] = useState<'SHADOW_RUN' | 'BENCHMARK' | 'ROADMAP'>('BENCHMARK');

  const handleRunReplay = () => {
    setIsRunningShadowReplay(true);
    setTimeout(() => {
      const newTx: ShadowRunTransaction = {
        id: `shw-${Date.now().toString().slice(-3)}`,
        description: 'Instant SEPA Corporate Supplier Settlement',
        amount: 870000.0,
        currency: 'EUR',
        legacyStatus: 'PROCESSING_BATCH',
        legacyLatencySeconds: 10800, // 3 hours in batch
        auraCoreStatus: 'SETTLED_REALTIME',
        auraCoreLatencyMs: 4.2,
        deltaMismatch: false,
      };
      setShadowTxs((prev) => [newTx, ...prev]);
      setReconciledCount((prev) => prev + 1);
      setIsRunningShadowReplay(false);
    }, 800);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-white">Core Modernization & Shadow-Running Studio</h1>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                Zero-Downtime Migration
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              De-risk core replacement through real-time shadow ledger dual-writing. Compare performance,
              architecture, and total cost of ownership against Thought Machine Vault Core and Temenos Transact.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('BENCHMARK')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeTab === 'BENCHMARK'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Competitive Benchmark
            </button>
            <button
              onClick={() => setActiveTab('SHADOW_RUN')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeTab === 'SHADOW_RUN'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Live Shadow-Run Simulator
            </button>
            <button
              onClick={() => setActiveTab('ROADMAP')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeTab === 'ROADMAP'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              4-Phase Cutover Plan
            </button>
          </div>
        </div>
      </div>

      {/* Tab 1: Competitive Benchmark */}
      {activeTab === 'BENCHMARK' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-white">Tier-1 Core Banking Comparative Matrix</h2>
              <p className="text-xs text-slate-400">
                Evaluation criteria for enterprise cloud-native core banking transformations.
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-cyan-400 font-medium">
                <span className="h-2 w-2 rounded-full bg-cyan-400"></span>
                AuraCore
              </span>
              <span className="flex items-center gap-1.5 text-slate-400">
                <span className="h-2 w-2 rounded-full bg-slate-500"></span>
                Thought Machine Vault
              </span>
              <span className="flex items-center gap-1.5 text-slate-400">
                <span className="h-2 w-2 rounded-full bg-slate-600"></span>
                Temenos Transact
              </span>
            </div>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/40 overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
                  <th className="py-3 px-4 w-1/5">Dimension</th>
                  <th className="py-3 px-4 w-1/4 text-cyan-300 font-semibold bg-cyan-950/20 border-x border-cyan-900/40">
                    AuraCore (Cloud-Native)
                  </th>
                  <th className="py-3 px-4 w-1/4">Thought Machine (Vault Core)</th>
                  <th className="py-3 px-4 w-1/4">Temenos (Transact / T24)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {MIGRATION_BENCHMARKS.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-slate-200 align-top">
                      {item.dimension}
                      <div className="text-[10px] text-emerald-400 mt-1 font-normal font-sans">
                        {item.impactAdvantage}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-100 bg-cyan-950/20 border-x border-cyan-900/40 align-top">
                      <div className="flex items-start gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{item.auraCore}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 align-top">
                      {item.thoughtMachineVault}
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 align-top">
                      {item.temenosTransact}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Live Shadow-Run Simulator */}
      {activeTab === 'SHADOW_RUN' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-sm font-semibold text-white">Parallel Shadow Accounting Replay</h2>
              <p className="text-xs text-slate-400">
                Transactions are ingested into both the legacy core and AuraCore simultaneously to prove 100% balance reconciliation.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4" />
                <span>Reconciliation: {reconciledCount}/{reconciledCount} (0% Delta)</span>
              </div>
              <button
                onClick={handleRunReplay}
                disabled={isRunningShadowReplay}
                className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-3 py-1.5 text-xs font-medium text-slate-950 hover:bg-cyan-400 disabled:opacity-50"
              >
                <Play className={`h-3 w-3 ${isRunningShadowReplay ? 'animate-spin' : ''}`} />
                <span>{isRunningShadowReplay ? 'Replaying...' : 'Replay Shadow Transaction'}</span>
              </button>
            </div>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/40 overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
                  <th className="py-3 px-4">Transaction Details</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4">Legacy Core (Temenos/Batch)</th>
                  <th className="py-3 px-4 text-cyan-300">AuraCore (Cloud-Native)</th>
                  <th className="py-3 px-4 text-center">Variance Proof</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {shadowTxs.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{tx.description}</div>
                      <div className="text-[11px] font-mono text-slate-400">{tx.id}</div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-white font-semibold">
                      {tx.currency} {tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-amber-400">
                      <div>{tx.legacyStatus}</div>
                      <div className="text-slate-400 text-[10px]">
                        Queue lag: {(tx.legacyLatencySeconds / 3600).toFixed(1)} hrs
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-emerald-400">
                      <div>SETTLED REALTIME</div>
                      <div className="text-cyan-400 text-[10px] font-semibold">
                        Commit: {tx.auraCoreLatencyMs} ms
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-flex items-center gap-1 font-mono text-[11px] text-emerald-400">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>$0.00 MATCH</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: 4-Phase Cutover Plan */}
      {activeTab === 'ROADMAP' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <span className="text-[11px] font-mono text-cyan-400">Phase 01</span>
            <h3 className="text-sm font-semibold text-white">Event Streaming Gateway</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Kafka change-data-capture taps existing legacy core transactions and streams them into AuraCore without production risk.
            </p>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <span className="text-[11px] font-mono text-cyan-400">Phase 02</span>
            <h3 className="text-sm font-semibold text-white">Shadow Ledger Accounting</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Parallel run verifies ledger postings, interest calculations, and ISO 20022 schemas across millions of historical accounts.
            </p>
          </div>

          <div className="rounded border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <span className="text-[11px] font-mono text-cyan-400">Phase 03</span>
            <h3 className="text-sm font-semibold text-white">Product-by-Product Migration</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Launch net-new digital deposits and smart contract high-yield accounts natively on AuraCore, bypassing legacy change freezes.
            </p>
          </div>

          <div className="rounded border border-emerald-900/60 bg-emerald-950/20 p-4 space-y-2">
            <span className="text-[11px] font-mono text-emerald-400">Phase 04</span>
            <h3 className="text-sm font-semibold text-emerald-300">Legacy Mainframe Cutover</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Flip routing keys at the payment orchestrator level. Decommission expensive mainframe MIPS and legacy licensing fees.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
