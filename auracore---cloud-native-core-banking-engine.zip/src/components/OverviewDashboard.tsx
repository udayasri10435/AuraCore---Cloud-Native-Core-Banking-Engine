import React from 'react';
import {
  TrendingUp,
  ShieldCheck,
  Zap,
  ArrowUpRight,
  Database,
  Server,
  Layers,
  Activity,
  CheckCircle2,
  Clock,
  Send,
  GitBranch,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { BankAccount, JournalEntry, PaymentTransaction } from '../types/banking';

interface OverviewDashboardProps {
  accounts: BankAccount[];
  journalEntries: JournalEntry[];
  payments: PaymentTransaction[];
  totalLedgerBalanceUsd: number;
  onNavigate: (view: string) => void;
  onSimulateInboundPayment: () => void;
  onRunAccrual: () => void;
  isAccrualRunning: boolean;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  accounts,
  journalEntries,
  payments,
  totalLedgerBalanceUsd,
  onNavigate,
  onSimulateInboundPayment,
  onRunAccrual,
  isAccrualRunning,
}) => {
  const latestJournals = journalEntries.slice(0, 5);
  const totalSettled24h = payments.reduce((sum, p) => sum + (p.status === 'SETTLED' ? p.amount : 0), 0);

  return (
    <div className="space-y-6">
      {/* Top Banner / Mission Statement */}
      <div className="rounded border border-slate-800 bg-slate-900/60 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-white">
              Cloud-Native Core Banking Engine
            </h1>
            <p className="mt-1 text-sm text-slate-400 max-w-2xl leading-relaxed">
              Real-time multi-currency double-entry ledger with microsecond partition locking,
              declarative smart contracts, native ISO 20022 rails orchestration, and automated KYC onboarding.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onSimulateInboundPayment}
              className="inline-flex items-center gap-1.5 rounded border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-medium text-slate-200 transition-colors hover:border-slate-600 hover:bg-slate-700"
            >
              <Zap className="h-3.5 w-3.5 text-cyan-400" />
              <span>Simulate $2.5M FedNow Wire</span>
            </button>
            <button
              onClick={onRunAccrual}
              disabled={isAccrualRunning}
              className="inline-flex items-center gap-1.5 rounded border border-cyan-800/60 bg-cyan-950/60 px-3 py-2 text-xs font-medium text-cyan-300 transition-colors hover:bg-cyan-900/60"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isAccrualRunning ? 'animate-spin' : ''}`} />
              <span>{isAccrualRunning ? 'Calculating Accruals...' : 'Run EOD Interest Accrual'}</span>
            </button>
            <button
              onClick={() => onNavigate('migration')}
              className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-3.5 py-2 text-xs font-medium text-slate-950 transition-colors hover:bg-cyan-400"
            >
              <span>Shadow Run vs Temenos/Vault</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Metric 1: Total Ledger Value */}
        <div className="rounded border border-slate-800 bg-slate-900/40 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Core Ledger Balance</span>
            <Database className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-white">
            ${totalLedgerBalanceUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="text-emerald-400 font-mono font-medium">100% Balanced</span>
            <span aria-hidden="true">·</span>
            <span>{accounts.length} core accounts</span>
          </div>
        </div>

        {/* Metric 2: Double-Entry Invariant */}
        <div className="rounded border border-slate-800 bg-slate-900/40 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Ledger Invariant Inbalance</span>
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-emerald-400">
            $0.0000
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="text-slate-300 font-mono">Σ Debits = Σ Credits</span>
            <span aria-hidden="true">·</span>
            <span>Mathematical proof</span>
          </div>
        </div>

        {/* Metric 3: Core Latency & Throughput */}
        <div className="rounded border border-slate-800 bg-slate-900/40 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Peak Core Engine Throughput</span>
            <Activity className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-white">
            45,200 <span className="text-xs font-normal text-slate-400">TPS</span>
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="text-emerald-400 font-mono font-medium">3.8 ms</span>
            <span>average commit latency</span>
          </div>
        </div>

        {/* Metric 4: ISO 20022 Settlements */}
        <div className="rounded border border-slate-800 bg-slate-900/40 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>24h Real-Time Settlement</span>
            <Send className="h-4 w-4 text-blue-400" />
          </div>
          <div className="mt-2 text-2xl font-semibold font-mono tabular-nums text-white">
            ${totalSettled24h.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="mt-1 text-xs text-slate-400 flex items-center gap-1.5">
            <span className="text-cyan-400 font-mono font-medium">{payments.length} wires</span>
            <span aria-hidden="true">·</span>
            <span>FedNow / SEPA / FPS / SWIFT</span>
          </div>
        </div>
      </div>

      {/* Real-time Settlement Rails Status */}
      <div className="rounded border border-slate-800 bg-slate-900/40 p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-semibold text-white">Direct Real-Time Payment Rails</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Native ISO 20022 XML parsing and clearing orchestration without third-party aggregator latency
            </p>
          </div>
          <button
            onClick={() => onNavigate('payments')}
            className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            <span>Open Rails Console</span>
            <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
          {/* FedNow */}
          <div className="rounded border border-slate-800/80 bg-slate-950/60 p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-xs text-white">FedNow (USA)</span>
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                ACTIVE
              </span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>Standard</span>
              <span className="font-mono text-slate-300">pacs.008.001.10</span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>Settlement Latency</span>
              <span className="font-mono text-cyan-400 font-medium">420 ms</span>
            </div>
          </div>

          {/* SEPA Instant */}
          <div className="rounded border border-slate-800/80 bg-slate-950/60 p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-xs text-white">SEPA Instant (EU)</span>
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                ACTIVE
              </span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>Standard</span>
              <span className="font-mono text-slate-300">SCT Inst (EPC)</span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>Settlement Latency</span>
              <span className="font-mono text-cyan-400 font-medium">680 ms</span>
            </div>
          </div>

          {/* Faster Payments (UK) */}
          <div className="rounded border border-slate-800/80 bg-slate-950/60 p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-xs text-white">Faster Payments (UK)</span>
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                ACTIVE
              </span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>Standard</span>
              <span className="font-mono text-slate-300">NPA ISO 20022</span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>Settlement Latency</span>
              <span className="font-mono text-cyan-400 font-medium">290 ms</span>
            </div>
          </div>

          {/* SWIFT gpi */}
          <div className="rounded border border-slate-800/80 bg-slate-950/60 p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-xs text-white">SWIFT gpi Cross-Border</span>
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                ACTIVE
              </span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>Standard</span>
              <span className="font-mono text-slate-300">CBPR+ ISO 20022</span>
            </div>
            <div className="text-xs text-slate-400 flex justify-between">
              <span>UETR Tracking</span>
              <span className="font-mono text-cyan-400 font-medium">Real-time</span>
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Architecture Topology & Recent Journal Postings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Core Architecture Topology Card */}
        <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-semibold text-white">Cloud-Native Core Topology</h2>
              <p className="text-xs text-slate-400">Next-gen decoupled architecture vs legacy monoliths</p>
            </div>
            <span className="text-xs font-mono text-cyan-400">v4.2 Architecture</span>
          </div>

          <div className="space-y-3">
            {/* Layer 1: Ingestion */}
            <div className="rounded border border-slate-800 bg-slate-950/70 p-3 flex items-start gap-3">
              <div className="rounded bg-cyan-950 p-2 text-cyan-400 shrink-0">
                <Send className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-slate-200">1. Ingestion & Payments Gateway</h3>
                  <span className="text-[11px] font-mono text-slate-400">gRPC & Kafka</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Validates ISO 20022 schemas, executes sanction screening (OFAC / PEP), and generates deterministic idempotency keys.
                </p>
              </div>
            </div>

            {/* Layer 2: Smart Contract Engine */}
            <div className="rounded border border-slate-800 bg-slate-950/70 p-3 flex items-start gap-3">
              <div className="rounded bg-blue-950 p-2 text-blue-400 shrink-0">
                <GitBranch className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-slate-200">2. Smart Contract Product Logic</h3>
                  <span className="text-[11px] font-mono text-slate-400">Declarative Python</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Evaluates interest tiers, overdraft headroom, and fee schedules. Translates business events into pure posting instructions.
                </p>
              </div>
            </div>

            {/* Layer 3: Universal Double-Entry Ledger Core */}
            <div className="rounded border border-cyan-900/60 bg-cyan-950/20 p-3 flex items-start gap-3">
              <div className="rounded bg-cyan-500/20 p-2 text-cyan-300 shrink-0">
                <Database className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-cyan-300">3. Universal Double-Entry Ledger</h3>
                  <span className="text-[11px] font-mono text-emerald-400 font-semibold">Strict ACID Invariant</span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  Atomic state commits. Enforces mathematical balance across sub-account partitions: Available, Pending Hold, Lien, and Accruals.
                </p>
              </div>
            </div>

            {/* Layer 4: Real-Time Partition State Store */}
            <div className="rounded border border-slate-800 bg-slate-950/70 p-3 flex items-start gap-3">
              <div className="rounded bg-indigo-950 p-2 text-indigo-400 shrink-0">
                <Layers className="h-4 w-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-slate-200">4. Microsecond Balance Partitions</h3>
                  <span className="text-[11px] font-mono text-slate-400">Zero-Lock Shards</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Instant balance lookups and hold reservations without locking entire customer account records or database tables.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Real-Time Journal Stream */}
        <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-semibold text-white">Live Journal Stream</h2>
              <p className="text-xs text-slate-400">Immutable double-entry debit & credit postings</p>
            </div>
            <button
              onClick={() => onNavigate('ledger')}
              className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>View All ({journalEntries.length})</span>
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-2.5">
            {latestJournals.map((jnl) => (
              <div
                key={jnl.id}
                className="rounded border border-slate-800/80 bg-slate-950/60 p-3 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200 truncate pr-2">
                    {jnl.description}
                  </span>
                  <span className="font-mono tabular-nums text-cyan-400 font-medium shrink-0">
                    ${jnl.totalDebit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-400">{jnl.referenceId}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-emerald-400">Balanced (2 legs)</span>
                  </div>
                  <span className="font-mono text-slate-400">
                    {new Date(jnl.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
