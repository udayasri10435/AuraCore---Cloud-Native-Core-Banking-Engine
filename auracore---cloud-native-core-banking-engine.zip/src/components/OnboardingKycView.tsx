import React, { useState } from 'react';
import {
  UserCheck,
  UserPlus,
  Search,
  ShieldAlert,
  ShieldCheck,
  Building2,
  User,
  CheckCircle2,
  FileCheck,
  ArrowRight,
  Sparkles,
  CreditCard,
  Plus,
} from 'lucide-react';
import { CustomerKycRecord, BankAccount, CurrencyCode } from '../types/banking';

interface OnboardingKycViewProps {
  customers: CustomerKycRecord[];
  accounts: BankAccount[];
  onAddNewCustomer: (newCustomer: CustomerKycRecord, newAccount: BankAccount, initialDeposit: number) => void;
}

export const OnboardingKycView: React.FC<OnboardingKycViewProps> = ({
  customers,
  accounts,
  onAddNewCustomer,
}) => {
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'RETAIL' | 'COMMERCIAL'>('ALL');

  // Wizard state
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4>(1);
  const [entityType, setEntityType] = useState<'RETAIL_INDIVIDUAL' | 'COMMERCIAL_CORPORATE'>('RETAIL_INDIVIDUAL');
  const [legalName, setLegalName] = useState('');
  const [taxId, setTaxId] = useState('');
  const [country, setCountry] = useState('United States');
  const [documentType, setDocumentType] = useState<'PASSPORT' | 'DRIVERS_LICENSE' | 'ARTICLES_OF_INCORPORATION'>('PASSPORT');
  const [documentNumber, setDocumentNumber] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('USD');
  const [initialDepositAmount, setInitialDepositAmount] = useState<number>(50000);
  const [isScreening, setIsScreening] = useState(false);
  const [screeningResult, setScreeningResult] = useState<{
    pepMatch: boolean;
    ofacClean: boolean;
    riskScore: number;
    riskTier: 'LOW' | 'MEDIUM' | 'HIGH';
  } | null>(null);

  const filteredCustomers = customers.filter((cust) => {
    const matchesFilter =
      filterType === 'ALL' ||
      (filterType === 'RETAIL' && cust.customerType === 'RETAIL_INDIVIDUAL') ||
      (filterType === 'COMMERCIAL' && cust.customerType === 'COMMERCIAL_CORPORATE');

    const matchesSearch =
      searchQuery === '' ||
      cust.legalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cust.taxIdentifier.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cust.countryOfResidence.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const handleRunScreening = () => {
    setIsScreening(true);
    setTimeout(() => {
      setIsScreening(false);
      setScreeningResult({
        pepMatch: false,
        ofacClean: true,
        riskScore: Math.floor(Math.random() * 12) + 2,
        riskTier: 'LOW',
      });
      setWizardStep(3);
    }, 700);
  };

  const handleFinishOnboarding = () => {
    const custId = `cust-${Date.now().toString().slice(-6)}`;
    const accId = `acc-${Date.now().toString().slice(-4)}`;
    const randomAccNum = `${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const prefix = selectedCurrency === 'USD' ? 'US89AURB00' : selectedCurrency === 'EUR' ? 'DE44AURB00' : 'GB29AURA00';
    const iban = `${prefix}${randomAccNum.replace(/-/g, '')}`;

    const newCustomer: CustomerKycRecord = {
      id: custId,
      customerType: entityType,
      legalName: legalName || (entityType === 'RETAIL_INDIVIDUAL' ? 'Alex Mercer' : 'Apex Technologies Corp'),
      taxIdentifier: taxId || '492-01-8841',
      countryOfResidence: country,
      riskTier: screeningResult?.riskTier || 'LOW',
      kycStatus: 'VERIFIED',
      pepSanctionMatch: false,
      onboardedAt: new Date().toISOString(),
      assignedAccounts: [accId],
      totalDeposits: initialDepositAmount,
      documentType,
      documentNumber: documentNumber || 'DOC-994821',
    };

    const newAccount: BankAccount = {
      id: accId,
      accountNumber: randomAccNum,
      iban,
      holderName: newCustomer.legalName,
      customerId: custId,
      type: entityType === 'RETAIL_INDIVIDUAL' ? 'RETAIL_CHECKING' : 'COMMERCIAL_TREASURY',
      currency: selectedCurrency,
      partitions: {
        available: initialDepositAmount,
        pendingHold: 0,
        lienCollateral: 0,
        accruedInterest: 0,
        ledgerTotal: initialDepositAmount,
      },
      status: 'ACTIVE',
      productId: 'prod-smart-savings',
      openedAt: new Date().toISOString(),
      branchCode: 'NYC-DIGITAL',
    };

    onAddNewCustomer(newCustomer, newAccount, initialDepositAmount);

    // Reset wizard
    setIsWizardOpen(false);
    setWizardStep(1);
    setLegalName('');
    setTaxId('');
    setDocumentNumber('');
    setScreeningResult(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 rounded border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold text-white">Customer Onboarding & KYC Pipeline</h1>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
              Automated Identity Proofing
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Streamlined digital entity verification, automated PEP & OFAC watchlist sanctions screening,
            and instant sub-second core ledger account provisioning.
          </p>
        </div>

        <button
          onClick={() => setIsWizardOpen(true)}
          className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-3.5 py-1.5 text-xs font-medium text-slate-950 transition-colors hover:bg-cyan-400"
        >
          <UserPlus className="h-3.5 w-3.5" />
          <span>Launch Onboarding Wizard</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 rounded border border-slate-800 bg-slate-900/40 p-3">
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded border border-slate-800">
          {[
            { id: 'ALL', label: 'All Customers' },
            { id: 'RETAIL', label: 'Retail Individuals' },
            { id: 'COMMERCIAL', label: 'Commercial Entities' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                filterType === tab.id
                  ? 'bg-slate-800 text-cyan-300 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative min-w-[260px]">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by legal name, tax ID, or country..."
            className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 pl-9 pr-3 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="rounded border border-slate-800 bg-slate-900/40 overflow-hidden">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
              <th className="py-3 px-4">Legal Entity Name</th>
              <th className="py-3 px-4">Entity Type</th>
              <th className="py-3 px-4">Tax ID / SSN</th>
              <th className="py-3 px-4">Country</th>
              <th className="py-3 px-4">Risk Tier</th>
              <th className="py-3 px-4">KYC Status</th>
              <th className="py-3 px-4 text-right">Core Deposits</th>
              <th className="py-3 px-4 text-center">Accounts</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {filteredCustomers.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-8 text-center text-slate-500">
                  No customers found matching filter.
                </td>
              </tr>
            ) : (
              filteredCustomers.map((cust) => (
                <tr key={cust.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-semibold text-white flex items-center gap-2">
                    {cust.customerType === 'COMMERCIAL_CORPORATE' ? (
                      <Building2 className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
                    ) : (
                      <User className="h-3.5 w-3.5 text-blue-400 shrink-0" />
                    )}
                    <span>{cust.legalName}</span>
                  </td>
                  <td className="py-3 px-4 text-slate-400 text-[11px]">
                    {cust.customerType === 'COMMERCIAL_CORPORATE' ? 'Commercial Corp' : 'Retail Individual'}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">{cust.taxIdentifier}</td>
                  <td className="py-3 px-4 text-slate-300">{cust.countryOfResidence}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1 font-mono text-[10px] ${
                        cust.riskTier === 'LOW'
                          ? 'text-emerald-400'
                          : cust.riskTier === 'MEDIUM'
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-current"></span>
                      {cust.riskTier} RISK
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center gap-1 font-mono text-[11px] text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                      <span>{cust.kycStatus}</span>
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-white font-semibold">
                    ${cust.totalDeposits.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3 px-4 text-center font-mono text-slate-400">
                    {cust.assignedAccounts.length}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Onboarding Wizard Modal */}
      {isWizardOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl rounded-lg border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-semibold text-white">Digital Onboarding & KYC Wizard</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Step {wizardStep} of 4: {wizardStep === 1 ? 'Entity Identification' : wizardStep === 2 ? 'Document Verification & AML' : wizardStep === 3 ? 'Core Account Provisioning' : 'Confirmation'}
                </p>
              </div>
              <button
                onClick={() => setIsWizardOpen(false)}
                className="text-slate-400 hover:text-slate-200 text-xs px-2 py-1 rounded"
              >
                Cancel
              </button>
            </div>

            {/* Step 1: Entity Details */}
            {wizardStep === 1 && (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">Customer Classification</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setEntityType('RETAIL_INDIVIDUAL')}
                      className={`p-3 rounded border text-left text-xs transition-colors flex items-center gap-2.5 ${
                        entityType === 'RETAIL_INDIVIDUAL'
                          ? 'border-cyan-500 bg-cyan-950/30 text-white'
                          : 'border-slate-800 bg-slate-950 text-slate-400'
                      }`}
                    >
                      <User className="h-4 w-4 text-cyan-400 shrink-0" />
                      <div>
                        <div className="font-semibold text-white">Retail Individual</div>
                        <div className="text-[10px] text-slate-400">Personal Banking & Checking</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setEntityType('COMMERCIAL_CORPORATE')}
                      className={`p-3 rounded border text-left text-xs transition-colors flex items-center gap-2.5 ${
                        entityType === 'COMMERCIAL_CORPORATE'
                          ? 'border-cyan-500 bg-cyan-950/30 text-white'
                          : 'border-slate-800 bg-slate-950 text-slate-400'
                      }`}
                    >
                      <Building2 className="h-4 w-4 text-cyan-400 shrink-0" />
                      <div>
                        <div className="font-semibold text-white">Commercial Corporate</div>
                        <div className="text-[10px] text-slate-400">Enterprise & Treasury Pool</div>
                      </div>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    {entityType === 'RETAIL_INDIVIDUAL' ? 'Full Legal Name' : 'Registered Corporate Name'}
                  </label>
                  <input
                    type="text"
                    value={legalName}
                    onChange={(e) => setLegalName(e.target.value)}
                    placeholder={entityType === 'RETAIL_INDIVIDUAL' ? 'e.g. Maya Lin' : 'e.g. Helios Robotics Inc.'}
                    className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-slate-300 block mb-1">
                      {entityType === 'RETAIL_INDIVIDUAL' ? 'Tax ID / SSN' : 'EIN / Tax Identifier'}
                    </label>
                    <input
                      type="text"
                      value={taxId}
                      onChange={(e) => setTaxId(e.target.value)}
                      placeholder="e.g. 991-20-4821"
                      className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-medium text-slate-300 block mb-1">Jurisdiction / Country</label>
                    <select
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs text-white focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="United States">United States</option>
                      <option value="United Kingdom">United Kingdom</option>
                      <option value="Germany">Germany</option>
                      <option value="Singapore">Singapore</option>
                      <option value="Switzerland">Switzerland</option>
                    </select>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => setWizardStep(2)}
                    className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-4 py-2 text-xs font-medium text-slate-950 hover:bg-cyan-400"
                  >
                    <span>Proceed to KYC Verification</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: KYC & AML Sanction Screening */}
            {wizardStep === 2 && (
              <div className="space-y-4">
                <div className="rounded border border-slate-800 bg-slate-950 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">Identity Proofing Document</span>
                    <FileCheck className="h-4 w-4 text-cyan-400" />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Document Type</label>
                      <select
                        value={documentType}
                        onChange={(e) => setDocumentType(e.target.value as any)}
                        className="w-full rounded border border-slate-800 bg-slate-900 py-1.5 px-2.5 text-xs text-white"
                      >
                        <option value="PASSPORT">Passport</option>
                        <option value="DRIVERS_LICENSE">Driver's License</option>
                        <option value="ARTICLES_OF_INCORPORATION">Articles of Inc</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Document Number</label>
                      <input
                        type="text"
                        value={documentNumber}
                        onChange={(e) => setDocumentNumber(e.target.value)}
                        placeholder="e.g. PASS-9920194"
                        className="w-full rounded border border-slate-800 bg-slate-900 py-1.5 px-2.5 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="rounded border border-slate-800 bg-slate-950 p-4 space-y-2 text-xs">
                  <div className="font-semibold text-white flex items-center justify-between">
                    <span>Automated Sanctions & PEP Check</span>
                    <ShieldCheck className="h-4 w-4 text-emerald-400" />
                  </div>
                  <p className="text-slate-400 text-[11px]">
                    Real-time match against OFAC Specially Designated Nationals (SDN), Interpol, and Politically Exposed Persons (PEP).
                  </p>
                </div>

                <div className="pt-2 flex justify-between">
                  <button
                    onClick={() => setWizardStep(1)}
                    className="rounded border border-slate-800 px-3 py-1.5 text-xs text-slate-300"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleRunScreening}
                    disabled={isScreening}
                    className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-4 py-2 text-xs font-medium text-slate-950 hover:bg-cyan-400 disabled:opacity-50"
                  >
                    {isScreening ? (
                      <span>Screening Databases...</span>
                    ) : (
                      <>
                        <span>Execute AML Verification</span>
                        <ArrowRight className="h-3.5 w-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Account Provisioning */}
            {wizardStep === 3 && (
              <div className="space-y-4">
                <div className="rounded border border-emerald-900/60 bg-emerald-950/20 p-3.5 flex items-center gap-3">
                  <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
                  <div>
                    <div className="text-xs font-semibold text-emerald-300">Sanctions Pre-Flight Passed</div>
                    <div className="text-[11px] text-slate-300">
                      No matches found in OFAC or PEP databases. Risk assessment: LOW (Score 4/100).
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-slate-300 block mb-1">Base Currency</label>
                    <select
                      value={selectedCurrency}
                      onChange={(e) => setSelectedCurrency(e.target.value as CurrencyCode)}
                      className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white"
                    >
                      <option value="USD">USD - United States Dollar</option>
                      <option value="EUR">EUR - Euro</option>
                      <option value="GBP">GBP - British Pound</option>
                      <option value="CHF">CHF - Swiss Franc</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-medium text-slate-300 block mb-1">
                      Initial Core Opening Deposit
                    </label>
                    <input
                      type="number"
                      value={initialDepositAmount}
                      onChange={(e) => setInitialDepositAmount(Number(e.target.value))}
                      className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white"
                    />
                  </div>
                </div>

                <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-400 space-y-1">
                  <div className="font-semibold text-slate-200">Automated Ledger Actions upon Submit:</div>
                  <div>1. Provisions IBAN and assigns to customer entity.</div>
                  <div>2. Initializes balance partitions (Available, Pending Hold, Lien Collateral, Accrued Interest).</div>
                  <div>3. Posts balanced double-entry opening deposit from Central Bank Nostro to customer ledger.</div>
                </div>

                <div className="pt-2 flex justify-between">
                  <button
                    onClick={() => setWizardStep(2)}
                    className="rounded border border-slate-800 px-3 py-1.5 text-xs text-slate-300"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleFinishOnboarding}
                    className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-4 py-2 text-xs font-medium text-slate-950 hover:bg-cyan-400"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>Provision Core Account Now</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
