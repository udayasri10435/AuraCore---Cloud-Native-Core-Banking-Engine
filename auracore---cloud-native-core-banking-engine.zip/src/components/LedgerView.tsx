import React, { useState } from 'react';
import {
  ShieldCheck,
  Search,
  Filter,
  Plus,
  ChevronDown,
  ChevronUp,
  Download,
  Database,
  ArrowRightLeft,
  Lock,
  Layers,
  CheckCircle,
} from 'lucide-react';
import { BankAccount, JournalEntry } from '../types/banking';

interface LedgerViewProps {
  accounts: BankAccount[];
  journalEntries: JournalEntry[];
  onOpenNewPosting: () => void;
  onSelectAccount?: (account: BankAccount) => void;
}

export const LedgerView: React.FC<LedgerViewProps> = ({
  accounts,
  journalEntries,
  onOpenNewPosting,
  onSelectAccount,
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedEntryId, setExpandedEntryId] = useState<string | null>(null);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('all');

  // Filter journals
  const filteredJournals = journalEntries.filter((jnl) => {
    const matchesType =
      filterType === 'ALL' ||
      (filterType === 'SETTLEMENT' && jnl.postingType === 'PAYMENT_SETTLEMENT') ||
      (filterType === 'TRANSFER' && jnl.postingType === 'CUSTOMER_TRANSFER') ||
      (filterType === 'ACCRUAL' && jnl.postingType === 'INTEREST_ACCRUAL') ||
      (filterType === 'HOLD' && (jnl.postingType === 'HOLD_AUTHORIZATION' || jnl.postingType === 'HOLD_RELEASE'));

    const matchesSearch =
      searchQuery === '' ||
      jnl.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      jnl.referenceId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      jnl.legs.some((leg) => leg.accountName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesAccount =
      selectedAccountId === 'all' ||
      jnl.legs.some((leg) => leg.accountId === selectedAccountId);

    return matchesType && matchesSearch && matchesAccount;
  });

  const exportAuditLog = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(journalEntries, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `auracore_ledger_audit_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      {/* Top Ledger Header & Invariant Status */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 rounded border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold text-white">Universal Double-Entry Ledger</h1>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
              ACID Compliant
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Continuous immutable append-only journal entries. Zero-variance balance invariant with multi-currency
            partition isolation (Available, Pending Hold, Lien Collateral, Accrued Interest).
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={exportAuditLog}
            className="inline-flex items-center gap-1.5 rounded border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:bg-slate-700"
          >
            <Download className="h-3.5 w-3.5 text-slate-400" />
            <span>Export Audit Log</span>
          </button>
          <button
            onClick={onOpenNewPosting}
            className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-3.5 py-1.5 text-xs font-medium text-slate-950 transition-colors hover:bg-cyan-400"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Create Manual Posting</span>
          </button>
        </div>
      </div>

      {/* Account Balance Partitions Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Layers className="h-4 w-4 text-cyan-400" />
            <span>Core Account Balance Partitions</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {accounts.length} provisioned accounts
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {accounts.slice(0, 4).map((acc) => (
            <div
              key={acc.id}
              onClick={() => setSelectedAccountId(selectedAccountId === acc.id ? 'all' : acc.id)}
              className={`cursor-pointer rounded border p-4 transition-all ${
                selectedAccountId === acc.id
                  ? 'border-cyan-500 bg-slate-900/90 shadow-md ring-1 ring-cyan-500'
                  : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xs font-semibold text-white truncate max-w-[170px]" title={acc.holderName}>
                    {acc.holderName}
                  </h3>
                  <div className="text-[11px] font-mono text-slate-400 mt-0.5">{acc.accountNumber}</div>
                </div>
                <span className="text-[10px] font-mono text-cyan-400 border border-slate-700 bg-slate-800 px-1.5 py-0.5 rounded">
                  {acc.currency}
                </span>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-800/80">
                <div className="text-[11px] text-slate-400 flex justify-between">
                  <span>Ledger Total:</span>
                  <span className="font-mono tabular-nums text-white font-semibold">
                    {acc.currency} {acc.partitions.ledgerTotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="mt-2 space-y-1 text-[10px] text-slate-400">
                  <div className="flex justify-between">
                    <span>Available:</span>
                    <span className="font-mono text-slate-300">
                      {acc.partitions.available.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  {acc.partitions.pendingHold > 0 && (
                    <div className="flex justify-between text-amber-400">
                      <span>Pending Hold:</span>
                      <span className="font-mono">
                        {acc.partitions.pendingHold.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  )}
                  {acc.partitions.lienCollateral > 0 && (
                    <div className="flex justify-between text-indigo-400">
                      <span>Lien Collateral:</span>
                      <span className="font-mono">
                        {acc.partitions.lienCollateral.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  )}
                  {acc.partitions.accruedInterest !== 0 && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Accrued Interest:</span>
                      <span className="font-mono">
                        {acc.partitions.accruedInterest.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 rounded border border-slate-800 bg-slate-900/40 p-3">
        {/* Interactive segmented filter control */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded border border-slate-800">
          {[
            { id: 'ALL', label: 'All Journals' },
            { id: 'SETTLEMENT', label: 'Settlements' },
            { id: 'TRANSFER', label: 'Transfers' },
            { id: 'ACCRUAL', label: 'Accruals' },
            { id: 'HOLD', label: 'Holds & Liens' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                filterType === tab.id
                  ? 'bg-slate-800 text-cyan-300 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative min-w-[260px]">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by ref, desc, or account..."
            className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 pl-9 pr-3 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Journal Entries Table */}
      <div className="rounded border border-slate-800 bg-slate-900/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
                <th className="py-3 px-4">Seq #</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Reference ID</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4 text-right">Debit / Credit</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredJournals.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No journal entries matching current filters.
                  </td>
                </tr>
              ) : (
                filteredJournals.map((jnl) => {
                  const isExpanded = expandedEntryId === jnl.id;
                  return (
                    <React.Fragment key={jnl.id}>
                      <tr
                        onClick={() => setExpandedEntryId(isExpanded ? null : jnl.id)}
                        className="cursor-pointer hover:bg-slate-800/40 transition-colors"
                      >
                        <td className="py-3 px-4 font-mono text-slate-400">#{jnl.sequenceNumber}</td>
                        <td className="py-3 px-4 font-mono text-slate-400">
                          {new Date(jnl.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                          })}
                        </td>
                        <td className="py-3 px-4 font-mono text-cyan-400 font-medium">{jnl.referenceId}</td>
                        <td className="py-3 px-4 text-slate-200 max-w-xs truncate">{jnl.description}</td>
                        <td className="py-3 px-4 text-slate-400">
                          {jnl.postingType.replace(/_/g, ' ')}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-white font-semibold">
                          ${jnl.totalDebit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className="inline-flex items-center gap-1 font-mono text-[11px] text-emerald-400">
                            <CheckCircle className="h-3 w-3" />
                            <span>POSTED</span>
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center text-slate-400">
                          {isExpanded ? (
                            <ChevronUp className="h-4 w-4 inline" />
                          ) : (
                            <ChevronDown className="h-4 w-4 inline" />
                          )}
                        </td>
                      </tr>

                      {/* Expandable Legs Detail */}
                      {isExpanded && (
                        <tr className="bg-slate-950/70">
                          <td colSpan={8} className="py-4 px-6 border-y border-slate-800">
                            <div className="space-y-3">
                              <div className="flex items-center justify-between text-xs">
                                <span className="font-semibold text-slate-300">
                                  Double-Entry Balanced Postings ({jnl.legs.length} legs)
                                </span>
                                <div className="flex items-center gap-4 text-xs font-mono">
                                  <span className="text-slate-400">
                                    Total Debit: <span className="text-white">${jnl.totalDebit.toFixed(2)}</span>
                                  </span>
                                  <span className="text-slate-400">
                                    Total Credit: <span className="text-white">${jnl.totalCredit.toFixed(2)}</span>
                                  </span>
                                  <span className="text-emerald-400 font-semibold">Variance: $0.00</span>
                                </div>
                              </div>

                              <div className="space-y-1.5 font-mono text-xs">
                                {jnl.legs.map((leg, index) => (
                                  <div
                                    key={index}
                                    className={`flex items-center justify-between p-2 rounded border ${
                                      leg.type === 'DEBIT'
                                        ? 'border-blue-900/50 bg-blue-950/20 text-blue-200'
                                        : 'border-emerald-900/50 bg-emerald-950/20 text-emerald-200'
                                    }`}
                                  >
                                    <div className="flex items-center gap-3">
                                      <span
                                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                          leg.type === 'DEBIT'
                                            ? 'bg-blue-900/80 text-blue-300'
                                            : 'bg-emerald-900/80 text-emerald-300'
                                        }`}
                                      >
                                        {leg.type}
                                      </span>
                                      <span className="text-slate-200">{leg.accountName}</span>
                                      {leg.partitionTarget && (
                                        <span className="text-[10px] text-slate-400">
                                          [partition: {leg.partitionTarget}]
                                        </span>
                                      )}
                                    </div>
                                    <div className="tabular-nums font-semibold">
                                      {leg.currency} {leg.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                    </div>
                                  </div>
                                ))}
                              </div>

                              {jnl.contractRuleTriggered && (
                                <div className="text-[11px] text-cyan-400 bg-cyan-950/40 p-2 rounded border border-cyan-800/40">
                                  Triggered by: {jnl.contractRuleTriggered}
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
