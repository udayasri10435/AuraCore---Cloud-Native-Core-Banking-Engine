import React, { useState } from 'react';
import { SendHorizontal, X, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { BankAccount, PaymentRail, PaymentTransaction, JournalEntry, CurrencyCode } from '../types/banking';

interface NewPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: BankAccount[];
  onSubmitPayment: (newTx: PaymentTransaction, newJournal: JournalEntry) => void;
}

export const NewPaymentModal: React.FC<NewPaymentModalProps> = ({
  isOpen,
  onClose,
  accounts,
  onSubmitPayment,
}) => {
  const [senderAccountId, setSenderAccountId] = useState<string>(accounts[0]?.id || '');
  const [rail, setRail] = useState<PaymentRail>('FedNow');
  const [receiverName, setReceiverName] = useState<string>('Standard Chartered Treasury UK');
  const [receiverIban, setReceiverIban] = useState<string>('GB29SCBL0000009948210982');
  const [receiverBic, setReceiverBic] = useState<string>('SCBLGB2LXXX');
  const [amount, setAmount] = useState<number>(125000);
  const [remittance, setRemittance] = useState<string>('CROSS-BORDER LIQUIDITY FACILITY SETTLEMENT');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!isOpen) return null;

  const senderAccount = accounts.find((a) => a.id === senderAccountId) || accounts[0];

  const handleSendPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      alert('Please specify a valid payment amount.');
      return;
    }

    if (amount > senderAccount.partitions.available) {
      alert(`Insufficient available funds in sender account. Available: ${senderAccount.currency} ${senderAccount.partitions.available.toLocaleString()}`);
      return;
    }

    setIsProcessing(true);

    setTimeout(() => {
      const uetr = `c${Math.random().toString(16).slice(2, 10)}-${Math.random().toString(16).slice(2, 6)}-498c-8f47-${Math.random().toString(16).slice(2, 14)}`;
      const endToEndId = `AUR-${Date.now().toString().slice(-8)}-${rail.slice(0, 3).toUpperCase()}`;

      const isoXmlPayload = `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.10">
  <FIToFICstmrCdtTrf>
    <GrpHdr>
      <MsgId>AURA-${Date.now()}</MsgId>
      <CreDtTm>${new Date().toISOString()}</CreDtTm>
      <NbOfTxs>1</NbOfTxs>
      <SttlmInf><ClrSys><Prtry>${rail}</Prtry></ClrSys></SttlmInf>
    </GrpHdr>
    <CdtTrfTxInf>
      <PmtId>
        <EndToEndId>${endToEndId}</EndToEndId>
        <UETR>${uetr}</UETR>
      </PmtId>
      <IntrBkSttlmAmt Ccy="${senderAccount.currency}">${amount.toFixed(2)}</IntrBkSttlmAmt>
      <Dbtr><Nm>${senderAccount.holderName}</Nm></Dbtr>
      <DbtrAcct><Id><IBAN>${senderAccount.iban}</Id></DbtrAcct>
      <CdtrAgt><FinInstnId><BICFI>${receiverBic}</BICFI></FinInstnId></CdtrAgt>
      <Cdtr><Nm>${receiverName}</Nm></Cdtr>
      <CdtrAcct><Id><IBAN>${receiverIban}</Id></CdtrAcct>
      <RmtInf><Ustrd>${remittance}</Ustrd></RmtInf>
    </CdtTrfTxInf>
  </FIToFICstmrCdtTrf>
</Document>`;

      const newTx: PaymentTransaction = {
        id: `tx-${Date.now()}`,
        endToEndId,
        uetr,
        messageType: 'pacs.008.001.10',
        rail,
        senderAccountId: senderAccount.id,
        senderName: senderAccount.holderName,
        senderIban: senderAccount.iban,
        receiverAccountId: `ext-${Date.now().toString().slice(-4)}`,
        receiverName,
        receiverIban,
        receiverBic,
        amount,
        currency: senderAccount.currency,
        remittanceInformation: remittance,
        status: 'SETTLED',
        sanctionCheckScore: Math.floor(Math.random() * 5) + 1,
        timestamp: new Date().toISOString(),
        settlementDurationMs: rail === 'FedNow' ? 380 : rail === 'FPS_UK' ? 240 : 640,
        isoXmlPayload,
      };

      const newJournal: JournalEntry = {
        id: `jnl-pay-${Date.now()}`,
        sequenceNumber: Math.floor(10550 + Math.random() * 800),
        timestamp: new Date().toISOString(),
        effectiveDate: new Date().toISOString().split('T')[0],
        description: `ISO 20022 ${rail} Wire: ${senderAccount.holderName} → ${receiverName}`,
        referenceId: endToEndId,
        postingType: 'PAYMENT_SETTLEMENT',
        settlementRail: rail,
        totalDebit: amount,
        totalCredit: amount,
        balanced: true,
        status: 'POSTED',
        legs: [
          {
            accountId: senderAccount.id,
            accountName: senderAccount.holderName,
            type: 'DEBIT',
            amount,
            currency: senderAccount.currency,
            partitionTarget: 'available',
          },
          {
            accountId: 'acc-nostro-fed',
            accountName: 'Federal Reserve Nostro / Rail Clearing Float',
            type: 'CREDIT',
            amount,
            currency: senderAccount.currency,
            partitionTarget: 'available',
          },
        ],
      };

      onSubmitPayment(newTx, newJournal);
      setIsProcessing(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl rounded-lg border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-semibold text-white">Dispatch ISO 20022 Payment (pacs.008)</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Direct routing via FedNow, SEPA Instant, FPS UK, or SWIFT gpi rails.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 text-xs px-2 py-1 rounded"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSendPayment} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Debtor / Sender Account</label>
              <select
                value={senderAccountId}
                onChange={(e) => setSenderAccountId(e.target.value)}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs text-white"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.holderName} (Avail: ${acc.partitions.available.toLocaleString()})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Settlement Rail</label>
              <select
                value={rail}
                onChange={(e) => setRail(e.target.value as PaymentRail)}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white"
              >
                <option value="FedNow">FedNow (US Real-Time)</option>
                <option value="SEPA_Instant">SEPA Instant (EU SCT Inst)</option>
                <option value="FPS_UK">Faster Payments (UK FPS)</option>
                <option value="SWIFT_gpi">SWIFT gpi Cross-Border</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Creditor / Beneficiary Name</label>
              <input
                type="text"
                required
                value={receiverName}
                onChange={(e) => setReceiverName(e.target.value)}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Payment Amount ($)</label>
              <input
                type="number"
                min="0.01"
                step="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Beneficiary IBAN</label>
              <input
                type="text"
                required
                value={receiverIban}
                onChange={(e) => setReceiverIban(e.target.value)}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Creditor BIC / SWIFT</label>
              <input
                type="text"
                required
                value={receiverBic}
                onChange={(e) => setReceiverBic(e.target.value)}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">Remittance Information</label>
            <input
              type="text"
              required
              value={remittance}
              onChange={(e) => setRemittance(e.target.value)}
              className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs text-white"
            />
          </div>

          {/* Sanction Screening & Double-entry Note */}
          <div className="rounded border border-slate-800 bg-slate-950 p-3 space-y-1.5 text-xs text-slate-400">
            <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <ShieldCheck className="h-4 w-4" />
              <span>Real-Time Pre-Flight Check: OFAC & Sanctions Scan Enabled</span>
            </div>
            <div>
              Funds will be immediately debited from sender partition and credited to rail Nostro clearing float.
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="rounded border border-slate-800 px-3.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing}
              className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-4 py-1.5 text-xs font-medium text-slate-950 hover:bg-cyan-400 disabled:opacity-50"
            >
              <SendHorizontal className="h-3.5 w-3.5" />
              <span>{isProcessing ? 'Routing via Rail...' : 'Dispatch ISO 20022 Wire'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
