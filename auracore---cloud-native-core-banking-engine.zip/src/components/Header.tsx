import React from 'react';
import { ShieldCheck, Plus, ArrowUpRight, Zap, RefreshCw } from 'lucide-react';

interface HeaderProps {
  activeView: string;
  setActiveView: (view: string) => void;
  onOpenNewPosting: () => void;
  onOpenNewPayment: () => void;
  onRunAccrual: () => void;
  isAccrualRunning: boolean;
  totalLedgerBalance: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  setActiveView,
  onOpenNewPosting,
  onOpenNewPayment,
  onRunAccrual,
  isAccrualRunning,
}) => {
  const navLinks = [
    { id: 'overview', label: 'Overview' },
    { id: 'ledger', label: 'Ledger' },
    { id: 'contracts', label: 'Smart Contracts' },
    { id: 'payments', label: 'Payments' },
    { id: 'onboarding', label: 'Onboarding' },
    { id: 'migration', label: 'Core Migration' },
  ];

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-800 bg-slate-950/90 px-6 backdrop-blur-md">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-4">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setActiveView('overview');
          }}
          className="text-lg font-semibold tracking-tight text-white transition-opacity hover:opacity-90 flex items-center gap-2.5"
        >
          <span className="flex h-7 w-7 items-center justify-center rounded bg-gradient-to-br from-cyan-500 to-blue-600 text-xs font-bold text-slate-950 shadow-sm">
            AC
          </span>
          <span>AuraCore Banking</span>
        </a>

        {/* Environmental status indicator */}
        <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400 pl-4 border-l border-slate-800">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Active-Active Multi-Region</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-slate-300 font-mono">Consensus: ACID v4</span>
        </div>
      </div>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
        {navLinks.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              activeView === item.id
                ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400 py-4 -mb-[18px]'
                : 'text-slate-400'
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* Zone 3: Primary actions */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={onRunAccrual}
          disabled={isAccrualRunning}
          title="Run contract interest accruals across all accounts"
          className="hidden sm:inline-flex items-center gap-1.5 rounded border border-slate-700 bg-slate-900/80 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-slate-600 hover:bg-slate-800 disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isAccrualRunning ? 'animate-spin text-cyan-400' : 'text-slate-400'}`} />
          <span>{isAccrualRunning ? 'Accruing...' : 'Run Accrual'}</span>
        </button>

        <button
          onClick={onOpenNewPayment}
          className="inline-flex items-center gap-1.5 rounded border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-slate-600 hover:bg-slate-800"
        >
          <ArrowUpRight className="h-3.5 w-3.5 text-cyan-400" />
          <span>Send ISO Wire</span>
        </button>

        <button
          onClick={onOpenNewPosting}
          className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-3.5 py-1.5 text-xs font-medium text-slate-950 transition-colors hover:bg-cyan-400 shadow-sm"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>New Posting</span>
        </button>
      </div>
    </header>
  );
};
