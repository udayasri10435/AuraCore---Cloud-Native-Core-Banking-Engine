import React, { useState } from 'react';
import { Plus, X, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react';
import { BankAccount, JournalEntry, CurrencyCode } from '../types/banking';

interface PostingModalProps {
  isOpen: boolean;
  onClose: () => void;
  accounts: BankAccount[];
  onSubmitPosting: (newEntry: JournalEntry) => void;
}

export const PostingModal: React.FC<PostingModalProps> = ({
  isOpen,
  onClose,
  accounts,
  onSubmitPosting,
}) => {
  const [debitAccountId, setDebitAccountId] = useState<string>(accounts[0]?.id || '');
  const [debitPartition, setDebitPartition] = useState<'available' | 'pendingHold' | 'lienCollateral' | 'accruedInterest'>('available');
  const [creditAccountId, setCreditAccountId] = useState<string>(accounts[1]?.id || '');
  const [creditPartition, setCreditPartition] = useState<'available' | 'pendingHold' | 'lienCollateral' | 'accruedInterest'>('available');
  const [amount, setAmount] = useState<number>(25000);
  const [description, setDescription] = useState<string>('Inter-bank Commercial Working Capital Transfer');
  const [postingType, setPostingType] = useState<JournalEntry['postingType']>('CUSTOMER_TRANSFER');

  if (!isOpen) return null;

  const debitAccount = accounts.find((a) => a.id === debitAccountId) || accounts[0];
  const creditAccount = accounts.find((a) => a.id === creditAccountId) || accounts[1];

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();

    if (amount <= 0) {
      alert('Posting amount must be strictly greater than 0.');
      return;
    }

    const newJournal: JournalEntry = {
      id: `jnl-${Date.now()}`,
      sequenceNumber: Math.floor(10500 + Math.random() * 900),
      timestamp: new Date().toISOString(),
      effectiveDate: new Date().toISOString().split('T')[0],
      description,
      referenceId: `TX-MAN-${Date.now().toString().slice(-6)}`,
      postingType,
      totalDebit: amount,
      totalCredit: amount,
      balanced: true,
      status: 'POSTED',
      legs: [
        {
          accountId: debitAccount.id,
          accountName: debitAccount.holderName,
          type: 'DEBIT',
          amount,
          currency: debitAccount.currency,
          partitionTarget: debitPartition,
        },
        {
          accountId: creditAccount.id,
          accountName: creditAccount.holderName,
          type: 'CREDIT',
          amount,
          currency: creditAccount.currency,
          partitionTarget: creditPartition,
        },
      ],
    };

    onSubmitPosting(newJournal);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl rounded-lg border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-semibold text-white">Create Double-Entry Posting</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Strict mathematical invariance: Σ Debits = Σ Credits committed in a single ACID block.
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 text-xs px-2 py-1 rounded"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handlePost} className="space-y-4">
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">
              Description / Business Context
            </label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs text-white focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Posting Type</label>
              <select
                value={postingType}
                onChange={(e) => setPostingType(e.target.value as any)}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs text-white focus:border-cyan-500 focus:outline-none"
              >
                <option value="CUSTOMER_TRANSFER">Customer Transfer</option>
                <option value="PAYMENT_SETTLEMENT">Payment Settlement</option>
                <option value="HOLD_AUTHORIZATION">Hold Authorization</option>
                <option value="HOLD_RELEASE">Hold Release</option>
                <option value="FEE_ASSESSMENT">Fee Assessment</option>
                <option value="INTEREST_ACCRUAL">Interest Accrual</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Amount ($)</label>
              <input
                type="number"
                min="0.01"
                step="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Leg 1: Debit */}
          <div className="rounded border border-blue-900/50 bg-blue-950/20 p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-blue-300">Leg 1: DEBIT Account (Source)</span>
              <span className="font-mono text-[11px] text-blue-300 font-semibold">
                ${amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Select Account</label>
                <select
                  value={debitAccountId}
                  onChange={(e) => setDebitAccountId(e.target.value)}
                  className="w-full rounded border border-slate-800 bg-slate-900 py-1.5 px-2.5 text-xs text-white"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.holderName} ({acc.currency})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Partition Target</label>
                <select
                  value={debitPartition}
                  onChange={(e) => setDebitPartition(e.target.value as any)}
                  className="w-full rounded border border-slate-800 bg-slate-900 py-1.5 px-2.5 text-xs text-white"
                >
                  <option value="available">Available Balance</option>
                  <option value="pendingHold">Pending Hold</option>
                  <option value="lienCollateral">Lien Collateral</option>
                  <option value="accruedInterest">Accrued Interest</option>
                </select>
              </div>
            </div>
          </div>

          {/* Leg 2: Credit */}
          <div className="rounded border border-emerald-900/50 bg-emerald-950/20 p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-emerald-300">Leg 2: CREDIT Account (Destination)</span>
              <span className="font-mono text-[11px] text-emerald-300 font-semibold">
                ${amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Select Account</label>
                <select
                  value={creditAccountId}
                  onChange={(e) => setCreditAccountId(e.target.value)}
                  className="w-full rounded border border-slate-800 bg-slate-900 py-1.5 px-2.5 text-xs text-white"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.holderName} ({acc.currency})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Partition Target</label>
                <select
                  value={creditPartition}
                  onChange={(e) => setCreditPartition(e.target.value as any)}
                  className="w-full rounded border border-slate-800 bg-slate-900 py-1.5 px-2.5 text-xs text-white"
                >
                  <option value="available">Available Balance</option>
                  <option value="pendingHold">Pending Hold</option>
                  <option value="lienCollateral">Lien Collateral</option>
                  <option value="accruedInterest">Accrued Interest</option>
                </select>
              </div>
            </div>
          </div>

          {/* Mathematical Invariance Badge */}
          <div className="flex items-center justify-between text-xs text-slate-400 bg-slate-950 p-2.5 rounded border border-slate-800">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <ShieldCheck className="h-4 w-4" />
              <span>Balanced: Total Debit ({amount}) == Total Credit ({amount})</span>
            </span>
            <span className="font-mono text-emerald-400 font-semibold">Variance: $0.00</span>
          </div>

          {/* Submit */}
          <div className="pt-2 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="rounded border border-slate-800 px-3.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-4 py-1.5 text-xs font-medium text-slate-950 hover:bg-cyan-400 shadow-sm"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Commit ACID Posting</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
