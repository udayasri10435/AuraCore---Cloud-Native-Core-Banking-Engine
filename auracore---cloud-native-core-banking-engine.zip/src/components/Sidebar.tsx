import React from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Code2,
  SendHorizontal,
  UserCheck,
  GitCompare,
  Database,
  ShieldCheck,
  Layers,
  Activity,
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  unbalancedCount: number;
  activeAccountsCount: number;
  totalTransactionsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  setActiveView,
  unbalancedCount,
  activeAccountsCount,
  totalTransactionsCount,
}) => {
  const menuItems = [
    {
      id: 'overview',
      label: 'Core Overview',
      icon: LayoutDashboard,
      description: 'System health & vital metrics',
    },
    {
      id: 'ledger',
      label: 'Double-Entry Ledger',
      icon: BookOpen,
      description: 'ACID journals & partitions',
      badge: unbalancedCount === 0 ? 'Balanced' : `${unbalancedCount} Unbalanced`,
      badgeOk: unbalancedCount === 0,
    },
    {
      id: 'contracts',
      label: 'Smart Contracts',
      icon: Code2,
      description: 'Declarative product engine',
    },
    {
      id: 'payments',
      label: 'ISO 20022 Payments',
      icon: SendHorizontal,
      description: 'FedNow, SEPA, FPS & SWIFT',
    },
    {
      id: 'onboarding',
      label: 'KYC & Onboarding',
      icon: UserCheck,
      description: 'Identity & core accounts',
    },
    {
      id: 'migration',
      label: 'Legacy Migration',
      icon: GitCompare,
      description: 'Shadow run vs Temenos/Vault',
    },
  ];

  return (
    <aside className="w-64 shrink-0 border-r border-slate-800 bg-slate-950 flex flex-col justify-between hidden md:flex">
      <div className="p-4 space-y-6">
        {/* Environment Badge */}
        <div className="rounded border border-slate-800/80 bg-slate-900/60 p-3">
          <div className="flex items-center justify-between text-xs font-medium text-slate-300">
            <span className="flex items-center gap-1.5">
              <Database className="h-3.5 w-3.5 text-cyan-400" />
              <span>Core Node: Primary</span>
            </span>
            <span className="text-[11px] font-mono text-emerald-400">ONLINE</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Latency SLA</span>
            <span className="font-mono text-slate-300">3.8 ms</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Isolation</span>
            <span className="font-mono text-slate-300">Multi-Tenant ACID</span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1">
          <div className="px-2 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Core Modules
          </div>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center justify-between rounded px-3 py-2.5 text-left text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-slate-800/90 text-cyan-300 border-l-2 border-cyan-400 pl-2.5'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <div className="truncate">
                    <div className="truncate font-medium">{item.label}</div>
                    <div className="text-[10px] text-slate-400 truncate">{item.description}</div>
                  </div>
                </div>
                {item.badge && (
                  <span
                    className={`ml-2 shrink-0 text-[10px] font-mono ${
                      item.badgeOk ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom ledger vitals summary */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/60">
        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
          Ledger Invariant Proof
        </div>
        <div className="space-y-1.5 text-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span>Accounts</span>
            <span className="font-mono text-slate-200">{activeAccountsCount} active</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Total Journals</span>
            <span className="font-mono text-slate-200">{totalTransactionsCount}</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Imbalance Delta</span>
            <span className="font-mono text-emerald-400 font-semibold">$0.0000</span>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-400">
          <ShieldCheck className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
          <span>Continuous cryptographically signed journal hashes</span>
        </div>
      </div>
    </aside>
  );
};
