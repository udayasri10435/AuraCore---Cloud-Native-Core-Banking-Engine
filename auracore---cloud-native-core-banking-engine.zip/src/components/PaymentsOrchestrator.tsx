import React, { useState } from 'react';
import {
  SendHorizontal,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Code,
  Layers,
  ArrowRight,
  ShieldCheck,
  FileText,
  Copy,
  Check,
} from 'lucide-react';
import { PaymentTransaction, PaymentRail } from '../types/banking';

interface PaymentsOrchestratorProps {
  payments: PaymentTransaction[];
  onOpenNewPayment: () => void;
}

export const PaymentsOrchestrator: React.FC<PaymentsOrchestratorProps> = ({
  payments,
  onOpenNewPayment,
}) => {
  const [selectedRail, setSelectedRail] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTxId, setSelectedTxId] = useState<string>(payments[0]?.id || '');
  const [copiedPayload, setCopiedPayload] = useState(false);

  const filteredPayments = payments.filter((tx) => {
    const matchesRail = selectedRail === 'ALL' || tx.rail === selectedRail;
    const matchesSearch =
      searchQuery === '' ||
      tx.endToEndId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.uetr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.senderName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.receiverName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRail && matchesSearch;
  });

  const activeTx = payments.find((p) => p.id === selectedTxId) || payments[0];

  const copyPayload = () => {
    if (activeTx?.isoXmlPayload) {
      navigator.clipboard.writeText(activeTx.isoXmlPayload);
      setCopiedPayload(true);
      setTimeout(() => setCopiedPayload(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 rounded border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold text-white">ISO 20022 Payments Orchestrator</h1>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
              Native XML & JSON Schema
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Real-time multi-rail routing across FedNow, SEPA Instant, UK Faster Payments, and SWIFT gpi with
            automated OFAC/PEP sanction pre-flight checks and sub-second settlement.
          </p>
        </div>

        <button
          onClick={onOpenNewPayment}
          className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-3.5 py-1.5 text-xs font-medium text-slate-950 transition-colors hover:bg-cyan-400"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Dispatch ISO 20022 Payment</span>
        </button>
      </div>

      {/* Rail Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 rounded border border-slate-800 bg-slate-900/40 p-3">
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded border border-slate-800 overflow-x-auto">
          {[
            { id: 'ALL', label: 'All Rails' },
            { id: 'FedNow', label: 'FedNow (US)' },
            { id: 'SEPA_Instant', label: 'SEPA Instant (EU)' },
            { id: 'FPS_UK', label: 'FPS (UK)' },
            { id: 'SWIFT_gpi', label: 'SWIFT gpi' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedRail(tab.id)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                selectedRail === tab.id
                  ? 'bg-slate-800 text-cyan-300 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative min-w-[240px]">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by UETR, End-to-End ID, or entity..."
            className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 pl-9 pr-3 text-xs text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Main Grid: Left Transactions List, Right Message Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Payments List (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="rounded border border-slate-800 bg-slate-900/40 overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/80 text-slate-400 font-medium">
                  <th className="py-3 px-3.5">End-to-End ID</th>
                  <th className="py-3 px-3.5">Rail</th>
                  <th className="py-3 px-3.5">Sender → Receiver</th>
                  <th className="py-3 px-3.5 text-right">Amount</th>
                  <th className="py-3 px-3.5 text-center">Status</th>
                  <th className="py-3 px-3.5 text-right">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredPayments.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      No payments found for current rail filters.
                    </td>
                  </tr>
                ) : (
                  filteredPayments.map((tx) => {
                    const isSelected = tx.id === activeTx?.id;
                    return (
                      <tr
                        key={tx.id}
                        onClick={() => setSelectedTxId(tx.id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-slate-800/80 text-white' : 'hover:bg-slate-800/40'
                        }`}
                      >
                        <td className="py-3 px-3.5 font-mono text-cyan-400 font-medium">
                          {tx.endToEndId.slice(0, 16)}...
                        </td>
                        <td className="py-3 px-3.5 text-slate-300 font-mono text-[11px]">{tx.rail}</td>
                        <td className="py-3 px-3.5 max-w-[140px] truncate text-slate-200">
                          {tx.senderName.split(' ')[0]} → {tx.receiverName.split(' ')[0]}
                        </td>
                        <td className="py-3 px-3.5 text-right font-mono tabular-nums text-white font-semibold">
                          {tx.currency} {tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3 px-3.5 text-center">
                          <span
                            className={`inline-flex items-center gap-1 font-mono text-[10px] ${
                              tx.status === 'SETTLED'
                                ? 'text-emerald-400'
                                : tx.status === 'CLEARING'
                                ? 'text-cyan-400'
                                : 'text-amber-400'
                            }`}
                          >
                            <span className="h-1.5 w-1.5 rounded-full bg-current"></span>
                            {tx.status}
                          </span>
                        </td>
                        <td className="py-3 px-3.5 text-right font-mono text-slate-400 text-[11px]">
                          {tx.settlementDurationMs}ms
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: ISO 20022 XML Message Payload Inspector (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {activeTx ? (
            <div className="rounded border border-slate-800 bg-slate-900/40 p-4 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 className="text-xs font-semibold text-white flex items-center gap-2">
                    <FileText className="h-4 w-4 text-cyan-400" />
                    <span>ISO 20022 Message Inspector</span>
                  </h3>
                  <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                    Schema: {activeTx.messageType}
                  </div>
                </div>

                <button
                  onClick={copyPayload}
                  className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200"
                >
                  {copiedPayload ? (
                    <Check className="h-3 w-3 text-emerald-400" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                  <span>{copiedPayload ? 'Copied' : 'Copy XML'}</span>
                </button>
              </div>

              {/* Transaction Key Details */}
              <div className="space-y-2 text-xs font-mono bg-slate-950 p-3 rounded border border-slate-800/80">
                <div className="flex justify-between">
                  <span className="text-slate-400">UETR:</span>
                  <span className="text-cyan-300 truncate max-w-[220px]" title={activeTx.uetr}>
                    {activeTx.uetr}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Debtor Account:</span>
                  <span className="text-slate-200">{activeTx.senderIban}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Creditor Account:</span>
                  <span className="text-slate-200">{activeTx.receiverIban}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Creditor Agent (BIC):</span>
                  <span className="text-slate-200">{activeTx.receiverBic}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">OFAC / AML Score:</span>
                  <span className="text-emerald-400 font-semibold">{activeTx.sanctionCheckScore} / 100 (Clean)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Remittance:</span>
                  <span className="text-slate-300 font-sans truncate max-w-[200px]" title={activeTx.remittanceInformation}>
                    {activeTx.remittanceInformation}
                  </span>
                </div>
              </div>

              {/* Raw XML Payload viewer */}
              <div>
                <div className="text-[11px] font-semibold text-slate-400 mb-1.5">
                  Raw Canonical XML Document
                </div>
                <pre className="font-mono text-[11px] text-cyan-300 bg-slate-950 p-3 rounded border border-slate-800 overflow-x-auto max-h-[300px] leading-relaxed">
                  {activeTx.isoXmlPayload}
                </pre>
              </div>
            </div>
          ) : (
            <div className="rounded border border-slate-800 bg-slate-900/40 p-8 text-center text-slate-500 text-xs">
              Select a transaction to inspect its ISO 20022 canonical payload.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
