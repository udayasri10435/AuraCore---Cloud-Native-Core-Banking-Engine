import React, { useState } from 'react';
import {
  Code2,
  Play,
  CheckCircle2,
  Sliders,
  FileCode,
  Layers,
  ArrowRight,
  TrendingUp,
  Percent,
  DollarSign,
  AlertCircle,
  Copy,
  Check,
} from 'lucide-react';
import { SmartContractProduct, BankAccount, JournalEntry } from '../types/banking';

interface SmartContractEngineProps {
  products: SmartContractProduct[];
  accounts: BankAccount[];
  onCommitPostingInstruction: (entry: JournalEntry) => void;
  onUpdateProductParams: (productId: string, newParams: Partial<SmartContractProduct['parameters']>) => void;
}

export const SmartContractEngine: React.FC<SmartContractEngineProps> = ({
  products,
  accounts,
  onCommitPostingInstruction,
  onUpdateProductParams,
}) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0].id);
  const [activeTab, setActiveTab] = useState<'SIMULATOR' | 'CODE' | 'PARAMETERS'>('SIMULATOR');
  const [copiedCode, setCopiedCode] = useState(false);

  // Simulation test state
  const selectedProduct = products.find((p) => p.id === selectedProductId) || products[0];
  const [testBalance, setTestBalance] = useState<number>(350000);
  const [testCurrency, setTestCurrency] = useState<string>('USD');
  const [simulationResult, setSimulationResult] = useState<{
    effectiveRate: number;
    dailyAccrual: number;
    annualYield: number;
    postingGenerated: boolean;
    ruleTriggered: string;
  } | null>(null);

  const [localInterestRate, setLocalInterestRate] = useState<number>(selectedProduct.parameters.interestRatePercent);
  const [localTierThreshold, setLocalTierThreshold] = useState<number>(selectedProduct.parameters.tierThresholdAmount);

  // When selected product changes, reset local state
  const handleSelectProduct = (prod: SmartContractProduct) => {
    setSelectedProductId(prod.id);
    setLocalInterestRate(prod.parameters.interestRatePercent);
    setLocalTierThreshold(prod.parameters.tierThresholdAmount);
    setSimulationResult(null);
  };

  const handleRunSimulation = () => {
    const isTierBonus = testBalance >= localTierThreshold;
    const effectiveRate = isTierBonus
      ? (localInterestRate + selectedProduct.parameters.tierBonusRatePercent) / 100
      : localInterestRate / 100;

    const dailyAccrual = Number(((testBalance * effectiveRate) / 365.25).toFixed(2));
    const annualYield = Number((testBalance * effectiveRate).toFixed(2));

    setSimulationResult({
      effectiveRate: effectiveRate * 100,
      dailyAccrual,
      annualYield,
      postingGenerated: true,
      ruleTriggered: isTierBonus
        ? `Tier-2 High-Balance Bonus Applied (+${selectedProduct.parameters.tierBonusRatePercent}%)`
        : 'Standard Tier Accrual Applied',
    });
  };

  const handlePostAccrualToLedger = () => {
    if (!simulationResult) return;
    const targetAccount = accounts[0]; // Post to primary corporate or user account
    const newEntry: JournalEntry = {
      id: `jnl-sim-${Date.now()}`,
      sequenceNumber: Math.floor(10500 + Math.random() * 1000),
      timestamp: new Date().toISOString(),
      effectiveDate: new Date().toISOString().split('T')[0],
      description: `Smart Contract Execution: ${selectedProduct.name} - Daily Accrual`,
      referenceId: `CTR-${selectedProduct.id.slice(0, 8).toUpperCase()}-${Date.now().toString().slice(-4)}`,
      postingType: 'INTEREST_ACCRUAL',
      contractRuleTriggered: `${selectedProduct.name} [${simulationResult.ruleTriggered}]`,
      totalDebit: simulationResult.dailyAccrual,
      totalCredit: simulationResult.dailyAccrual,
      balanced: true,
      status: 'POSTED',
      legs: [
        {
          accountId: 'acc-fee-revenue',
          accountName: 'Core Banking Fee / Expense Pool',
          type: 'DEBIT',
          amount: simulationResult.dailyAccrual,
          currency: targetAccount.currency,
          partitionTarget: 'available',
        },
        {
          accountId: targetAccount.id,
          accountName: targetAccount.holderName,
          type: 'CREDIT',
          amount: simulationResult.dailyAccrual,
          currency: targetAccount.currency,
          partitionTarget: 'accruedInterest',
        },
      ],
    };

    onCommitPostingInstruction(newEntry);
    alert(`Successfully generated and committed double-entry journal #${newEntry.sequenceNumber} to the universal ledger!`);
  };

  const handleSaveParams = () => {
    onUpdateProductParams(selectedProduct.id, {
      interestRatePercent: localInterestRate,
      tierThresholdAmount: localTierThreshold,
    });
    alert('Smart contract configuration updated across core nodes.');
  };

  const copyCode = () => {
    navigator.clipboard.writeText(selectedProduct.pythonContractCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="rounded border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-white">Declarative Smart Contract Engine</h1>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                Thought Machine Vault Model
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Write banking products as code in declarative Python contracts. Define parameters, hooks, and automated
              double-entry posting instructions without modifying core ledger schemas.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
            <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
            <span>Sandboxed Contract Runtime: Verified</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Catalog, Right Contract Studio */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Product Catalog */}
        <div className="space-y-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-1">
            Active Core Products ({products.length})
          </div>

          <div className="space-y-2">
            {products.map((prod) => {
              const isSelected = prod.id === selectedProductId;
              return (
                <div
                  key={prod.id}
                  onClick={() => handleSelectProduct(prod)}
                  className={`cursor-pointer rounded border p-4 transition-all ${
                    isSelected
                      ? 'border-cyan-500 bg-slate-900/90 shadow-md ring-1 ring-cyan-500'
                      : 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <h3 className="text-xs font-semibold text-white">{prod.name}</h3>
                    <span className="text-[10px] font-mono text-cyan-400 border border-slate-700 bg-slate-800 px-1.5 py-0.5 rounded">
                      v{prod.version}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-slate-400 line-clamp-2">{prod.description}</p>
                  <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>{prod.activeAccountsCount} accounts</span>
                    <span className="text-slate-300">
                      ${(prod.totalManagedBalance / 1000000).toFixed(1)}M AUM
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Contract Inspector & Simulator */}
        <div className="lg:col-span-2 space-y-4">
          {/* Tabs */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('SIMULATOR')}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                  activeTab === 'SIMULATOR'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Interactive Simulator
              </button>
              <button
                onClick={() => setActiveTab('CODE')}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                  activeTab === 'CODE'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Contract Python Code
              </button>
              <button
                onClick={() => setActiveTab('PARAMETERS')}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                  activeTab === 'PARAMETERS'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Parameters & Tiers
              </button>
            </div>

            <span className="text-xs text-slate-400 font-mono">
              Product ID: {selectedProduct.id}
            </span>
          </div>

          {/* Tab 1: Simulator */}
          {activeTab === 'SIMULATOR' && (
            <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-white">Live Execution Simulator</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Test contract calculations against ledger balance partitions and generate live double-entry postings.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Simulated Ledger Balance
                  </label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
                    <input
                      type="number"
                      value={testBalance}
                      onChange={(e) => setTestBalance(Number(e.target.value))}
                      className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 pl-8 pr-3 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Base APY Parameter (%)
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    value={localInterestRate}
                    onChange={(e) => setLocalInterestRate(Number(e.target.value))}
                    className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleRunSimulation}
                  className="inline-flex items-center gap-1.5 rounded bg-cyan-500 px-4 py-2 text-xs font-medium text-slate-950 hover:bg-cyan-400 transition-colors shadow-sm"
                >
                  <Play className="h-3.5 w-3.5" />
                  <span>Execute Contract Hook</span>
                </button>
              </div>

              {/* Simulation Result */}
              {simulationResult && (
                <div className="rounded border border-cyan-900/60 bg-cyan-950/20 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                      <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                      <span>Contract Hook Evaluated Successfully</span>
                    </span>
                    <span className="text-[11px] font-mono text-emerald-400">Deterministic Pass</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div className="rounded bg-slate-950/60 p-2.5 border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Effective APY</span>
                      <span className="text-base font-semibold font-mono text-white mt-0.5 block">
                        {simulationResult.effectiveRate.toFixed(2)}%
                      </span>
                    </div>

                    <div className="rounded bg-slate-950/60 p-2.5 border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Daily Accrual Leg</span>
                      <span className="text-base font-semibold font-mono text-cyan-400 mt-0.5 block">
                        ${simulationResult.dailyAccrual.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div className="rounded bg-slate-950/60 p-2.5 border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Annualized Value</span>
                      <span className="text-base font-semibold font-mono text-white mt-0.5 block">
                        ${simulationResult.annualYield.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-300 bg-slate-950/60 p-2.5 rounded border border-slate-800 flex items-center justify-between">
                    <span>Active Rule: {simulationResult.ruleTriggered}</span>
                    <button
                      onClick={handlePostAccrualToLedger}
                      className="inline-flex items-center gap-1 text-xs font-medium text-cyan-400 hover:text-cyan-300 underline"
                    >
                      <span>Commit Posting to Universal Ledger</span>
                      <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Code Viewer */}
          {activeTab === 'CODE' && (
            <div className="rounded border border-slate-800 bg-slate-950 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <FileCode className="h-4 w-4 text-cyan-400" />
                  <span>Python Smart Contract Definition (PEP-8 Compliant)</span>
                </span>
                <button
                  onClick={copyCode}
                  className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200"
                >
                  {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>

              <pre className="font-mono text-xs text-slate-300 bg-slate-900/90 p-4 rounded border border-slate-800 overflow-x-auto leading-relaxed">
                {selectedProduct.pythonContractCode}
              </pre>
            </div>
          )}

          {/* Tab 3: Parameters */}
          {activeTab === 'PARAMETERS' && (
            <div className="rounded border border-slate-800 bg-slate-900/40 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Dynamic Product Parameters</h3>
                  <p className="text-xs text-slate-400">
                    Hot-reloadable parameters propagate to contract executions without database migrations.
                  </p>
                </div>
                <button
                  onClick={handleSaveParams}
                  className="rounded bg-cyan-500 px-3 py-1.5 text-xs font-medium text-slate-950 hover:bg-cyan-400"
                >
                  Save & Propagate
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Base Interest Rate (% APY)
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    value={localInterestRate}
                    onChange={(e) => setLocalInterestRate(Number(e.target.value))}
                    className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Tier Bonus Threshold ($)
                  </label>
                  <input
                    type="number"
                    value={localTierThreshold}
                    onChange={(e) => setLocalTierThreshold(Number(e.target.value))}
                    className="w-full rounded border border-slate-800 bg-slate-950 py-1.5 px-3 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Overdraft Limit ($)
                  </label>
                  <input
                    type="number"
                    disabled
                    value={selectedProduct.parameters.overdraftLimit}
                    className="w-full rounded border border-slate-800 bg-slate-950/60 py-1.5 px-3 text-xs font-mono text-slate-400 opacity-70"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-300 block mb-1">
                    Accrual Frequency
                  </label>
                  <input
                    type="text"
                    disabled
                    value={selectedProduct.parameters.interestCalculationFrequency}
                    className="w-full rounded border border-slate-800 bg-slate-950/60 py-1.5 px-3 text-xs font-mono text-slate-400 opacity-70"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
