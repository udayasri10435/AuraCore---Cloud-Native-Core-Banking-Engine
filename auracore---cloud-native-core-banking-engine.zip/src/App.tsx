/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { OverviewDashboard } from './components/OverviewDashboard';
import { LedgerView } from './components/LedgerView';
import { SmartContractEngine } from './components/SmartContractEngine';
import { PaymentsOrchestrator } from './components/PaymentsOrchestrator';
import { OnboardingKycView } from './components/OnboardingKycView';
import { MigrationStudio } from './components/MigrationStudio';
import { PostingModal } from './components/PostingModal';
import { NewPaymentModal } from './components/NewPaymentModal';

import {
  INITIAL_ACCOUNTS,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_SMART_CONTRACTS,
  INITIAL_PAYMENTS,
  INITIAL_CUSTOMERS,
} from './data/mockData';

import {
  BankAccount,
  JournalEntry,
  SmartContractProduct,
  PaymentTransaction,
  CustomerKycRecord,
} from './types/banking';

export default function App() {
  const [activeView, setActiveView] = useState<string>('overview');
  const [accounts, setAccounts] = useState<BankAccount[]>(INITIAL_ACCOUNTS);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [smartContracts, setSmartContracts] = useState<SmartContractProduct[]>(INITIAL_SMART_CONTRACTS);
  const [payments, setPayments] = useState<PaymentTransaction[]>(INITIAL_PAYMENTS);
  const [customers, setCustomers] = useState<CustomerKycRecord[]>(INITIAL_CUSTOMERS);

  // Modals
  const [isPostingModalOpen, setIsPostingModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isAccrualRunning, setIsAccrualRunning] = useState(false);

  // Calculate total core ledger balance across commercial & retail accounts
  const totalLedgerBalanceUsd = useMemo(() => {
    return accounts
      .filter((a) => a.type !== 'CENTRAL_BANK_NOSTRO' && a.type !== 'SETTLEMENT_CLEARING_FLOAT')
      .reduce((sum, a) => {
        // Approximate currency normalization for demo
        const rate = a.currency === 'GBP' ? 1.3 : a.currency === 'EUR' ? 1.08 : 1.0;
        return sum + a.partitions.ledgerTotal * rate;
      }, 0);
  }, [accounts]);

  // Double-entry posting commitment handler
  const handleCommitPosting = (newEntry: JournalEntry) => {
    // Apply state changes to account partitions
    setAccounts((prevAccounts) => {
      const updated = [...prevAccounts];
      newEntry.legs.forEach((leg) => {
        const targetAccIndex = updated.findIndex((a) => a.id === leg.accountId);
        if (targetAccIndex !== -1) {
          const acc = { ...updated[targetAccIndex] };
          const partitions = { ...acc.partitions };
          const pTarget = leg.partitionTarget || 'available';

          if (leg.type === 'DEBIT') {
            partitions[pTarget] = Math.max(0, partitions[pTarget] - leg.amount);
            partitions.ledgerTotal =
              partitions.available + partitions.pendingHold + partitions.lienCollateral;
          } else {
            partitions[pTarget] = partitions[pTarget] + leg.amount;
            partitions.ledgerTotal =
              partitions.available + partitions.pendingHold + partitions.lienCollateral;
          }

          acc.partitions = partitions;
          updated[targetAccIndex] = acc;
        }
      });
      return updated;
    });

    setJournalEntries((prev) => [newEntry, ...prev]);
  };

  // Payment submission handler
  const handleSubmitPayment = (newTx: PaymentTransaction, newJournal: JournalEntry) => {
    setPayments((prev) => [newTx, ...prev]);
    handleCommitPosting(newJournal);
  };

  // New customer onboarding handler
  const handleAddNewCustomer = (
    newCustomer: CustomerKycRecord,
    newAccount: BankAccount,
    initialDeposit: number
  ) => {
    setCustomers((prev) => [newCustomer, ...prev]);
    setAccounts((prev) => [newAccount, ...prev]);

    if (initialDeposit > 0) {
      const depositJournal: JournalEntry = {
        id: `jnl-open-${Date.now()}`,
        sequenceNumber: Math.floor(10600 + Math.random() * 500),
        timestamp: new Date().toISOString(),
        effectiveDate: new Date().toISOString().split('T')[0],
        description: `Core Account Provisioning: Opening Deposit for ${newCustomer.legalName}`,
        referenceId: `OPEN-${newAccount.accountNumber.slice(0, 8)}`,
        postingType: 'DEPOSIT_CREDIT',
        totalDebit: initialDeposit,
        totalCredit: initialDeposit,
        balanced: true,
        status: 'POSTED',
        legs: [
          {
            accountId: 'acc-nostro-fed',
            accountName: 'Federal Reserve Bank Nostro',
            type: 'DEBIT',
            amount: initialDeposit,
            currency: newAccount.currency,
            partitionTarget: 'available',
          },
          {
            accountId: newAccount.id,
            accountName: newAccount.holderName,
            type: 'CREDIT',
            amount: initialDeposit,
            currency: newAccount.currency,
            partitionTarget: 'available',
          },
        ],
      };
      setJournalEntries((prev) => [depositJournal, ...prev]);
    }
  };

  // Run interest accrual batch across all savings accounts
  const handleRunAccrual = () => {
    setIsAccrualRunning(true);
    setTimeout(() => {
      let totalAccrued = 0;
      const legs: JournalEntry['legs'] = [];

      accounts.forEach((acc) => {
        if (acc.type === 'HIGH_YIELD_SAVINGS' || acc.type === 'COMMERCIAL_TREASURY') {
          const rate = acc.type === 'HIGH_YIELD_SAVINGS' ? 0.0485 : 0.051;
          const dailyInterest = Number(((acc.partitions.available * rate) / 365.25).toFixed(2));
          if (dailyInterest > 0) {
            totalAccrued += dailyInterest;
            legs.push({
              accountId: acc.id,
              accountName: acc.holderName,
              type: 'CREDIT',
              amount: dailyInterest,
              currency: acc.currency,
              partitionTarget: 'accruedInterest',
            });
          }
        }
      });

      if (totalAccrued > 0) {
        legs.unshift({
          accountId: 'acc-fee-revenue',
          accountName: 'Central Bank / Core Expense Pool',
          type: 'DEBIT',
          amount: Number(totalAccrued.toFixed(2)),
          currency: 'USD',
          partitionTarget: 'available',
        });

        const accrualJournal: JournalEntry = {
          id: `jnl-batch-accrual-${Date.now()}`,
          sequenceNumber: Math.floor(10700 + Math.random() * 500),
          timestamp: new Date().toISOString(),
          effectiveDate: new Date().toISOString().split('T')[0],
          description: `End-of-Day Interest Accrual Batch (#${Math.floor(Math.random() * 900 + 100)})`,
          referenceId: `EOD-ACCRUAL-${Date.now().toString().slice(-6)}`,
          postingType: 'INTEREST_ACCRUAL',
          contractRuleTriggered: 'Dynamic Yield Smart Contract - Daily Batch Hook',
          totalDebit: Number(totalAccrued.toFixed(2)),
          totalCredit: Number(totalAccrued.toFixed(2)),
          balanced: true,
          status: 'POSTED',
          legs,
        };

        handleCommitPosting(accrualJournal);
      }

      setIsAccrualRunning(false);
    }, 700);
  };

  // Simulate an inbound payment
  const handleSimulateInboundPayment = () => {
    const inboundAmount = 2500000.0;
    const targetAccount = accounts[0]; // Vanguard Global Logistics

    const inboundJournal: JournalEntry = {
      id: `jnl-inbound-${Date.now()}`,
      sequenceNumber: Math.floor(10800 + Math.random() * 500),
      timestamp: new Date().toISOString(),
      effectiveDate: new Date().toISOString().split('T')[0],
      description: `Inbound FedNow Wire: Global Logistics Treasury Inflow`,
      referenceId: `FEDNOW-IN-${Date.now().toString().slice(-6)}`,
      postingType: 'PAYMENT_SETTLEMENT',
      settlementRail: 'FedNow',
      totalDebit: inboundAmount,
      totalCredit: inboundAmount,
      balanced: true,
      status: 'POSTED',
      legs: [
        {
          accountId: 'acc-nostro-fed',
          accountName: 'Federal Reserve Bank Nostro',
          type: 'DEBIT',
          amount: inboundAmount,
          currency: 'USD',
          partitionTarget: 'available',
        },
        {
          accountId: targetAccount.id,
          accountName: targetAccount.holderName,
          type: 'CREDIT',
          amount: inboundAmount,
          currency: 'USD',
          partitionTarget: 'available',
        },
      ],
    };

    handleCommitPosting(inboundJournal);
  };

  const handleUpdateProductParams = (
    productId: string,
    newParams: Partial<SmartContractProduct['parameters']>
  ) => {
    setSmartContracts((prev) =>
      prev.map((p) =>
        p.id === productId
          ? {
              ...p,
              parameters: {
                ...p.parameters,
                ...newParams,
              },
            }
          : p
      )
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Strict Top Bar Contract Header */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        onOpenNewPosting={() => setIsPostingModalOpen(true)}
        onOpenNewPayment={() => setIsPaymentModalOpen(true)}
        onRunAccrual={handleRunAccrual}
        isAccrualRunning={isAccrualRunning}
        totalLedgerBalance={totalLedgerBalanceUsd}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <Sidebar
          activeView={activeView}
          setActiveView={setActiveView}
          unbalancedCount={0}
          activeAccountsCount={accounts.length}
          totalTransactionsCount={journalEntries.length}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8 max-w-[1600px]">
          {activeView === 'overview' && (
            <OverviewDashboard
              accounts={accounts}
              journalEntries={journalEntries}
              payments={payments}
              totalLedgerBalanceUsd={totalLedgerBalanceUsd}
              onNavigate={setActiveView}
              onSimulateInboundPayment={handleSimulateInboundPayment}
              onRunAccrual={handleRunAccrual}
              isAccrualRunning={isAccrualRunning}
            />
          )}

          {activeView === 'ledger' && (
            <LedgerView
              accounts={accounts}
              journalEntries={journalEntries}
              onOpenNewPosting={() => setIsPostingModalOpen(true)}
            />
          )}

          {activeView === 'contracts' && (
            <SmartContractEngine
              products={smartContracts}
              accounts={accounts}
              onCommitPostingInstruction={handleCommitPosting}
              onUpdateProductParams={handleUpdateProductParams}
            />
          )}

          {activeView === 'payments' && (
            <PaymentsOrchestrator
              payments={payments}
              onOpenNewPayment={() => setIsPaymentModalOpen(true)}
            />
          )}

          {activeView === 'onboarding' && (
            <OnboardingKycView
              customers={customers}
              accounts={accounts}
              onAddNewCustomer={handleAddNewCustomer}
            />
          )}

          {activeView === 'migration' && <MigrationStudio />}
        </main>
      </div>

      {/* Interactive Modals */}
      <PostingModal
        isOpen={isPostingModalOpen}
        onClose={() => setIsPostingModalOpen(false)}
        accounts={accounts}
        onSubmitPosting={handleCommitPosting}
      />

      <NewPaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        accounts={accounts}
        onSubmitPayment={handleSubmitPayment}
      />
    </div>
  );
}
