import {
  BankAccount,
  JournalEntry,
  SmartContractProduct,
  PaymentTransaction,
  CustomerKycRecord,
  MigrationComparisonMetric,
  ShadowRunTransaction,
} from '../types/banking';

export const INITIAL_ACCOUNTS: BankAccount[] = [
  {
    id: 'acc-101',
    accountNumber: '4820-9182-3301',
    iban: 'US89AURB000000482091823301',
    holderName: 'Vanguard Global Logistics LLC',
    customerId: 'cust-corp-01',
    type: 'COMMERCIAL_TREASURY',
    currency: 'USD',
    partitions: {
      available: 14250800.5,
      pendingHold: 450000.0,
      lienCollateral: 1200000.0,
      accruedInterest: 18450.2,
      ledgerTotal: 15900800.5,
    },
    status: 'ACTIVE',
    productId: 'prod-treasury-01',
    openedAt: '2025-01-15T09:00:00Z',
    branchCode: 'NYC-CENTRAL',
  },
  {
    id: 'acc-102',
    accountNumber: '9211-4091-8842',
    iban: 'GB29AURA400821921140918842',
    holderName: 'Dr. Elena Rostova',
    customerId: 'cust-ret-01',
    type: 'HIGH_YIELD_SAVINGS',
    currency: 'GBP',
    partitions: {
      available: 485920.0,
      pendingHold: 0.0,
      lienCollateral: 0.0,
      accruedInterest: 1985.45,
      ledgerTotal: 485920.0,
    },
    status: 'ACTIVE',
    productId: 'prod-smart-savings',
    openedAt: '2025-03-10T14:22:00Z',
    branchCode: 'LON-MAYFAIR',
  },
  {
    id: 'acc-103',
    accountNumber: '1109-8472-6639',
    iban: 'DE44AURB500100110984726639',
    holderName: 'AeroDynamics Propulsion GmbH',
    customerId: 'cust-corp-02',
    type: 'SME_OVERDRAFT_CREDIT',
    currency: 'EUR',
    partitions: {
      available: 2150000.0,
      pendingHold: 125000.0,
      lienCollateral: 500000.0,
      accruedInterest: -3420.8,
      ledgerTotal: 2275000.0,
    },
    status: 'ACTIVE',
    productId: 'prod-sme-overdraft',
    openedAt: '2025-02-01T11:15:00Z',
    branchCode: 'FRA-MAIN',
  },
  {
    id: 'acc-104',
    accountNumber: '6733-1902-5544',
    iban: 'US12AURB000000673319025544',
    holderName: 'Marcus Aurelius Chen',
    customerId: 'cust-ret-02',
    type: 'RETAIL_CHECKING',
    currency: 'USD',
    partitions: {
      available: 84320.15,
      pendingHold: 1540.0,
      lienCollateral: 0.0,
      accruedInterest: 42.1,
      ledgerTotal: 85860.15,
    },
    status: 'ACTIVE',
    productId: 'prod-retail-checking',
    openedAt: '2025-04-18T16:45:00Z',
    branchCode: 'SFO-FINANCIAL',
  },
  {
    id: 'acc-nostro-fed',
    accountNumber: '0001-0000-FED0',
    iban: 'US00AURB99999900010000FED0',
    holderName: 'Federal Reserve Bank of New York (Nostro)',
    customerId: 'cust-system-01',
    type: 'CENTRAL_BANK_NOSTRO',
    currency: 'USD',
    partitions: {
      available: 125000000.0,
      pendingHold: 0.0,
      lienCollateral: 0.0,
      accruedInterest: 0.0,
      ledgerTotal: 125000000.0,
    },
    status: 'ACTIVE',
    productId: 'prod-treasury-01',
    openedAt: '2024-01-01T00:00:00Z',
    branchCode: 'SYS-CLEARING',
  },
  {
    id: 'acc-nostro-ecb',
    accountNumber: '0002-0000-ECB0',
    iban: 'DE00AURB99999900020000ECB0',
    holderName: 'European Central Bank TARGET-Instant (Nostro)',
    customerId: 'cust-system-02',
    type: 'CENTRAL_BANK_NOSTRO',
    currency: 'EUR',
    partitions: {
      available: 98000000.0,
      pendingHold: 0.0,
      lienCollateral: 0.0,
      accruedInterest: 0.0,
      ledgerTotal: 98000000.0,
    },
    status: 'ACTIVE',
    productId: 'prod-treasury-01',
    openedAt: '2024-01-01T00:00:00Z',
    branchCode: 'SYS-CLEARING',
  },
  {
    id: 'acc-float-clearing',
    accountNumber: '0099-FLOAT-001',
    iban: 'US99AURB0000000099FLOAT001',
    holderName: 'Universal Settlement & Clearing Float',
    customerId: 'cust-system-03',
    type: 'SETTLEMENT_CLEARING_FLOAT',
    currency: 'USD',
    partitions: {
      available: 0.0,
      pendingHold: 0.0,
      lienCollateral: 0.0,
      accruedInterest: 0.0,
      ledgerTotal: 0.0,
    },
    status: 'ACTIVE',
    productId: 'prod-treasury-01',
    openedAt: '2024-01-01T00:00:00Z',
    branchCode: 'SYS-CLEARING',
  },
  {
    id: 'acc-fee-revenue',
    accountNumber: '0088-FEE-REV',
    iban: 'US88AURB0000000088FEEREV01',
    holderName: 'Core Banking Fee Revenue Pool',
    customerId: 'cust-system-04',
    type: 'INTERNAL_FEES_REVENUE',
    currency: 'USD',
    partitions: {
      available: 489230.0,
      pendingHold: 0.0,
      lienCollateral: 0.0,
      accruedInterest: 0.0,
      ledgerTotal: 489230.0,
    },
    status: 'ACTIVE',
    productId: 'prod-treasury-01',
    openedAt: '2024-01-01T00:00:00Z',
    branchCode: 'SYS-TREASURY',
  },
];

export const INITIAL_JOURNAL_ENTRIES: JournalEntry[] = [
  {
    id: 'jnl-2026-0941',
    sequenceNumber: 10492,
    timestamp: '2026-09-29T01:58:12Z',
    effectiveDate: '2026-09-29',
    description: 'FedNow Instant Settlement: Inbound Corporate Treasury wire',
    referenceId: 'FEDNOW-IN-994821',
    postingType: 'PAYMENT_SETTLEMENT',
    settlementRail: 'FedNow',
    totalDebit: 2500000.0,
    totalCredit: 2500000.0,
    balanced: true,
    status: 'POSTED',
    legs: [
      {
        accountId: 'acc-nostro-fed',
        accountName: 'Federal Reserve Bank of New York (Nostro)',
        type: 'DEBIT',
        amount: 2500000.0,
        currency: 'USD',
        partitionTarget: 'available',
      },
      {
        accountId: 'acc-101',
        accountName: 'Vanguard Global Logistics LLC',
        type: 'CREDIT',
        amount: 2500000.0,
        currency: 'USD',
        partitionTarget: 'available',
      },
    ],
  },
  {
    id: 'jnl-2026-0940',
    sequenceNumber: 10491,
    timestamp: '2026-09-29T01:42:05Z',
    effectiveDate: '2026-09-29',
    description: 'Automated Overnight Interest Accrual (Smart Contract run #842)',
    referenceId: 'ACCRUAL-AUTO-0842',
    postingType: 'INTEREST_ACCRUAL',
    contractRuleTriggered: 'Smart High-Yield Contract - Rule 4.2 Daily Accrual',
    totalDebit: 1985.45,
    totalCredit: 1985.45,
    balanced: true,
    status: 'POSTED',
    legs: [
      {
        accountId: 'acc-fee-revenue',
        accountName: 'Core Banking Fee Revenue Pool',
        type: 'DEBIT',
        amount: 1985.45,
        currency: 'USD',
        partitionTarget: 'available',
      },
      {
        accountId: 'acc-102',
        accountName: 'Dr. Elena Rostova',
        type: 'CREDIT',
        amount: 1985.45,
        currency: 'GBP',
        partitionTarget: 'accruedInterest',
      },
    ],
  },
  {
    id: 'jnl-2026-0939',
    sequenceNumber: 10490,
    timestamp: '2026-09-29T00:15:33Z',
    effectiveDate: '2026-09-29',
    description: 'SEPA Instant Credit Transfer: Cross-border supplier clearance',
    referenceId: 'SEPA-INST-773190',
    postingType: 'CUSTOMER_TRANSFER',
    settlementRail: 'SEPA_Instant',
    totalDebit: 185000.0,
    totalCredit: 185000.0,
    balanced: true,
    status: 'POSTED',
    legs: [
      {
        accountId: 'acc-103',
        accountName: 'AeroDynamics Propulsion GmbH',
        type: 'DEBIT',
        amount: 185000.0,
        currency: 'EUR',
        partitionTarget: 'available',
      },
      {
        accountId: 'acc-nostro-ecb',
        accountName: 'European Central Bank TARGET-Instant (Nostro)',
        type: 'CREDIT',
        amount: 185000.0,
        currency: 'EUR',
        partitionTarget: 'available',
      },
    ],
  },
  {
    id: 'jnl-2026-0938',
    sequenceNumber: 10489,
    timestamp: '2026-09-28T23:51:10Z',
    effectiveDate: '2026-09-28',
    description: 'Pre-authorization Hold: Multi-currency Card Transaction',
    referenceId: 'AUTH-HOLD-559182',
    postingType: 'HOLD_AUTHORIZATION',
    totalDebit: 1540.0,
    totalCredit: 1540.0,
    balanced: true,
    status: 'POSTED',
    legs: [
      {
        accountId: 'acc-104',
        accountName: 'Marcus Aurelius Chen (Available)',
        type: 'DEBIT',
        amount: 1540.0,
        currency: 'USD',
        partitionTarget: 'available',
      },
      {
        accountId: 'acc-104',
        accountName: 'Marcus Aurelius Chen (Pending Hold Partition)',
        type: 'CREDIT',
        amount: 1540.0,
        currency: 'USD',
        partitionTarget: 'pendingHold',
      },
    ],
  },
  {
    id: 'jnl-2026-0937',
    sequenceNumber: 10488,
    timestamp: '2026-09-28T22:30:00Z',
    effectiveDate: '2026-09-28',
    description: 'Collateral Lien Placement: Overdraft facility backing',
    referenceId: 'LIEN-PLEDGE-0021',
    postingType: 'CUSTOMER_TRANSFER',
    totalDebit: 500000.0,
    totalCredit: 500000.0,
    balanced: true,
    status: 'POSTED',
    legs: [
      {
        accountId: 'acc-103',
        accountName: 'AeroDynamics Propulsion GmbH (Available)',
        type: 'DEBIT',
        amount: 500000.0,
        currency: 'EUR',
        partitionTarget: 'available',
      },
      {
        accountId: 'acc-103',
        accountName: 'AeroDynamics Propulsion GmbH (Lien Collateral Partition)',
        type: 'CREDIT',
        amount: 500000.0,
        currency: 'EUR',
        partitionTarget: 'lienCollateral',
      },
    ],
  },
];

export const INITIAL_SMART_CONTRACTS: SmartContractProduct[] = [
  {
    id: 'prod-smart-savings',
    name: 'VaultTier Dynamic High-Yield Savings',
    category: 'RETAIL',
    version: '3.4.1',
    description: 'Tiered yield calculation based on daily closing ledger balances with automated central bank base rate indexation.',
    pythonContractCode: `# AuraCore Smart Contract Product Definition
# Vault-compatible declarative logic
from auracore.contracts import Contract, Event, PostingInstruction

class DynamicHighYieldSavings(Contract):
    BASE_RATE = 0.0485  # 4.85% APY
    TIER_THRESHOLD = 250000.00
    TIER_BONUS_RATE = 0.0050  # +50 bps bonus for balances > 250k

    @Contract.hook(Event.END_OF_DAY)
    def calculate_interest(self, account, ledger_view):
        balance = ledger_view.get_partition(account.id, "available")
        if balance <= 0:
            return None
            
        rate = self.BASE_RATE
        if balance >= self.TIER_THRESHOLD:
            rate += self.TIER_BONUS_RATE
            
        daily_accrual = (balance * rate) / 365.25
        return PostingInstruction(
            debit_account="acc-interest-expense",
            credit_account=account.id,
            credit_partition="accruedInterest",
            amount=round(daily_accrual, 2),
            currency=account.currency,
            rule_id="ACCRUAL_RULE_TIERED"
        )`,
    parameters: {
      interestRatePercent: 4.85,
      interestCalculationFrequency: 'DAILY',
      tierThresholdAmount: 250000.0,
      tierBonusRatePercent: 0.5,
      overdraftLimit: 0,
      overdraftFeeDaily: 0,
      gracePeriodDays: 0,
      dormancyThresholdDays: 365,
    },
    activeAccountsCount: 1420,
    totalManagedBalance: 348200000.0,
    lastAccrualRun: '2026-09-29T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    id: 'prod-sme-overdraft',
    name: 'SME Adaptive Overdraft & Liquidity Sweep',
    category: 'COMMERCIAL',
    version: '2.8.0',
    description: 'Real-time multi-currency automated overdraft facility with collateral partition locks and automated end-of-day sweep.',
    pythonContractCode: `# SME Adaptive Overdraft Smart Contract
class AdaptiveOverdraft(Contract):
    OVERDRAFT_CEILING = 1000000.00
    COLLATERAL_RATIO = 0.50  # 50% collateral required in lien partition
    OVERDRAFT_MARGIN_BPS = 275  # SOFR + 275 bps

    @Contract.hook(Event.TRANSACTION_PRE_POSTING)
    def validate_available_funds(self, account, amount, currency):
        available = account.partitions["available"]
        lien = account.partitions["lienCollateral"]
        
        if amount > available:
            deficit = amount - available
            max_allowed = min(self.OVERDRAFT_CEILING, lien / self.COLLATERAL_RATIO)
            if deficit > max_allowed:
                raise InsufficientFundsException("Exceeds collateralized limit")
            return PostingInstruction.allow_with_overdraft(deficit)`,
    parameters: {
      interestRatePercent: 7.25,
      interestCalculationFrequency: 'DAILY',
      tierThresholdAmount: 500000.0,
      tierBonusRatePercent: 0.0,
      overdraftLimit: 1000000.0,
      overdraftFeeDaily: 25.0,
      gracePeriodDays: 3,
      dormancyThresholdDays: 180,
    },
    activeAccountsCount: 412,
    totalManagedBalance: 89400000.0,
    lastAccrualRun: '2026-09-29T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    id: 'prod-treasury-01',
    name: 'Institutional Multi-Currency Liquidity Pool',
    category: 'TREASURY',
    version: '4.0.0',
    description: 'Zero-latency multi-currency cross-border liquidity pooling with automated FX netting and FedNow/SEPA direct settlement.',
    pythonContractCode: `# Institutional Liquidity Pool Contract
class InstitutionalLiquidityPool(Contract):
    ZERO_BALANCE_SWEEP = True
    MINIMUM_FLOAT_BUFFER = 10000000.00
    
    @Contract.hook(Event.SWEEP_TRIGGER)
    def execute_multi_currency_netting(self, group_id, ledger):
        positions = ledger.get_consolidated_positions(group_id)
        for ccy, balance in positions.items():
            if balance > self.MINIMUM_FLOAT_BUFFER:
                ledger.post_internal_transfer(
                    from_account=group_id,
                    to_account="CENTRAL_TREASURY_CONCENTRATION",
                    amount=balance - self.MINIMUM_FLOAT_BUFFER,
                    currency=ccy
                )`,
    parameters: {
      interestRatePercent: 5.1,
      interestCalculationFrequency: 'DAILY',
      tierThresholdAmount: 10000000.0,
      tierBonusRatePercent: 0.25,
      overdraftLimit: 50000000.0,
      overdraftFeeDaily: 0,
      gracePeriodDays: 0,
      dormancyThresholdDays: 730,
    },
    activeAccountsCount: 88,
    totalManagedBalance: 1420000000.0,
    lastAccrualRun: '2026-09-29T00:00:00Z',
    status: 'ACTIVE',
  },
];

export const INITIAL_PAYMENTS: PaymentTransaction[] = [
  {
    id: 'tx-fed-9021',
    endToEndId: 'AUR-2026-0929-FED-001',
    uetr: 'f81d4fae-7dec-11d0-a765-00a0c91e6bf6',
    messageType: 'pacs.008.001.10',
    rail: 'FedNow',
    senderAccountId: 'acc-101',
    senderName: 'Vanguard Global Logistics LLC',
    senderIban: 'US89AURB000000482091823301',
    receiverAccountId: 'acc-ext-9921',
    receiverName: 'Pacific Maritime Terminal Corp',
    receiverIban: 'US33CHAS0000009918234810',
    receiverBic: 'CHASUS33XXX',
    amount: 745000.0,
    currency: 'USD',
    remittanceInformation: 'INVOICE #VGL-2026-99042 CARGO CLEARANCE',
    status: 'SETTLED',
    sanctionCheckScore: 4,
    timestamp: '2026-09-29T01:55:04Z',
    settlementDurationMs: 420,
    isoXmlPayload: `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.10">
  <FIToFICstmrCdtTrf>
    <GrpHdr>
      <MsgId>AURACMT-20260929-001</MsgId>
      <CreDtTm>2026-09-29T01:55:04Z</CreDtTm>
      <NbOfTxs>1</NbOfTxs>
      <SttlmInf>
        <SttlmMtd>CLRG</SttlmMtd>
        <ClrSys><Prtry>FedNow</Prtry></ClrSys>
      </SttlmInf>
    </GrpHdr>
    <CdtTrfTxInf>
      <PmtId>
        <EndToEndId>AUR-2026-0929-FED-001</EndToEndId>
        <UETR>f81d4fae-7dec-11d0-a765-00a0c91e6bf6</UETR>
      </PmtId>
      <IntrBkSttlmAmt Ccy="USD">745000.00</IntrBkSttlmAmt>
      <Dbtr><Nm>Vanguard Global Logistics LLC</Nm></Dbtr>
      <DbtrAcct><Id><IBAN>US89AURB000000482091823301</IBAN></Id></DbtrAcct>
      <CdtrAgt><FinInstnId><BICFI>CHASUS33XXX</BICFI></FinInstnId></CdtrAgt>
      <Cdtr><Nm>Pacific Maritime Terminal Corp</Nm></Cdtr>
      <CdtrAcct><Id><IBAN>US33CHAS0000009918234810</IBAN></Id></CdtrAcct>
      <RmtInf><Ustrd>INVOICE #VGL-2026-99042 CARGO CLEARANCE</Ustrd></RmtInf>
    </CdtTrfTxInf>
  </FIToFICstmrCdtTrf>
</Document>`,
  },
  {
    id: 'tx-sepa-4019',
    endToEndId: 'AUR-2026-0929-SEPA-882',
    uetr: '4b391780-f655-498c-8f47-2cb269d67e01',
    messageType: 'pacs.008.001.10',
    rail: 'SEPA_Instant',
    senderAccountId: 'acc-103',
    senderName: 'AeroDynamics Propulsion GmbH',
    senderIban: 'DE44AURB500100110984726639',
    receiverAccountId: 'acc-ext-8812',
    receiverName: 'Airbus Safran Launchers SAS',
    receiverIban: 'FR76BNPA0000004499182910',
    receiverBic: 'BNPAFR22XXX',
    amount: 185000.0,
    currency: 'EUR',
    remittanceInformation: 'PO-2026-TITANIUM-STAGE1-COMPONENTS',
    status: 'SETTLED',
    sanctionCheckScore: 2,
    timestamp: '2026-09-29T00:15:30Z',
    settlementDurationMs: 680,
    isoXmlPayload: `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.10">
  <FIToFICstmrCdtTrf>
    <GrpHdr>
      <MsgId>AURA-SEPA-20260929-882</MsgId>
      <CreDtTm>2026-09-29T00:15:30Z</CreDtTm>
      <SttlmInf><ClrSys><Prtry>SCT_INST</Prtry></ClrSys></SttlmInf>
    </GrpHdr>
    <CdtTrfTxInf>
      <IntrBkSttlmAmt Ccy="EUR">185000.00</IntrBkSttlmAmt>
      <Dbtr><Nm>AeroDynamics Propulsion GmbH</Nm></Dbtr>
      <Cdtr><Nm>Airbus Safran Launchers SAS</Nm></Cdtr>
      <RmtInf><Ustrd>PO-2026-TITANIUM-STAGE1-COMPONENTS</Ustrd></RmtInf>
    </CdtTrfTxInf>
  </FIToFICstmrCdtTrf>
</Document>`,
  },
  {
    id: 'tx-swift-8820',
    endToEndId: 'AUR-2026-0928-SWIFT-109',
    uetr: '8e8e788e-3294-4d89-bc01-e7a918a280f2',
    messageType: 'pacs.008.001.10',
    rail: 'SWIFT_gpi',
    senderAccountId: 'acc-101',
    senderName: 'Vanguard Global Logistics LLC',
    senderIban: 'US89AURB000000482091823301',
    receiverAccountId: 'acc-ext-tokyo',
    receiverName: 'Mitsubishi Heavy Industries Ltd',
    receiverIban: 'JP88BOTK0000001928374910',
    receiverBic: 'BOTKJPJTXXX',
    amount: 1450000.0,
    currency: 'USD',
    remittanceInformation: 'GLOBAL FORWARDING SETTLEMENT Q3',
    status: 'CLEARING',
    sanctionCheckScore: 6,
    timestamp: '2026-09-28T22:10:00Z',
    settlementDurationMs: 1840,
    isoXmlPayload: `<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.10">
  <FIToFICstmrCdtTrf>
    <GrpHdr><MsgId>AURA-SWIFT-GPI-109</MsgId></GrpHdr>
    <CdtTrfTxInf>
      <IntrBkSttlmAmt Ccy="USD">1450000.00</IntrBkSttlmAmt>
      <Dbtr><Nm>Vanguard Global Logistics LLC</Nm></Dbtr>
      <Cdtr><Nm>Mitsubishi Heavy Industries Ltd</Nm></Cdtr>
      <RmtInf><Ustrd>GLOBAL FORWARDING SETTLEMENT Q3</Ustrd></RmtInf>
    </CdtTrfTxInf>
  </FIToFICstmrCdtTrf>
</Document>`,
  },
];

export const INITIAL_CUSTOMERS: CustomerKycRecord[] = [
  {
    id: 'cust-corp-01',
    customerType: 'COMMERCIAL_CORPORATE',
    legalName: 'Vanguard Global Logistics LLC',
    taxIdentifier: '12-9984712',
    countryOfResidence: 'United States',
    riskTier: 'LOW',
    kycStatus: 'VERIFIED',
    pepSanctionMatch: false,
    onboardedAt: '2025-01-15T08:30:00Z',
    assignedAccounts: ['acc-101'],
    totalDeposits: 15900800.5,
    documentType: 'ARTICLES_OF_INCORPORATION',
    documentNumber: 'DE-CORP-2023-88910',
  },
  {
    id: 'cust-ret-01',
    customerType: 'RETAIL_INDIVIDUAL',
    legalName: 'Dr. Elena Rostova',
    taxIdentifier: 'GB-NINO-JR991823C',
    countryOfResidence: 'United Kingdom',
    riskTier: 'LOW',
    kycStatus: 'VERIFIED',
    pepSanctionMatch: false,
    onboardedAt: '2025-03-10T14:00:00Z',
    assignedAccounts: ['acc-102'],
    totalDeposits: 485920.0,
    documentType: 'PASSPORT',
    documentNumber: 'GB-PASS-99281726',
  },
  {
    id: 'cust-corp-02',
    customerType: 'COMMERCIAL_CORPORATE',
    legalName: 'AeroDynamics Propulsion GmbH',
    taxIdentifier: 'DE-VAT-992817462',
    countryOfResidence: 'Germany',
    riskTier: 'LOW',
    kycStatus: 'VERIFIED',
    pepSanctionMatch: false,
    onboardedAt: '2025-02-01T10:45:00Z',
    assignedAccounts: ['acc-103'],
    totalDeposits: 2275000.0,
    documentType: 'ARTICLES_OF_INCORPORATION',
    documentNumber: 'HRB-FRANKFURT-9921',
  },
  {
    id: 'cust-ret-02',
    customerType: 'RETAIL_INDIVIDUAL',
    legalName: 'Marcus Aurelius Chen',
    taxIdentifier: '492-88-1092',
    countryOfResidence: 'United States',
    riskTier: 'LOW',
    kycStatus: 'VERIFIED',
    pepSanctionMatch: false,
    onboardedAt: '2025-04-18T16:00:00Z',
    assignedAccounts: ['acc-104'],
    totalDeposits: 85860.15,
    documentType: 'DRIVERS_LICENSE',
    documentNumber: 'CA-DL-F9928190',
  },
  {
    id: 'cust-ret-03',
    customerType: 'RETAIL_INDIVIDUAL',
    legalName: 'Astrid Lindqvist',
    taxIdentifier: 'SE-PNR-840912-4412',
    countryOfResidence: 'Sweden',
    riskTier: 'MEDIUM',
    kycStatus: 'ENHANCED_DUE_DILIGENCE',
    pepSanctionMatch: false,
    onboardedAt: '2026-08-11T12:00:00Z',
    assignedAccounts: [],
    totalDeposits: 0.0,
    documentType: 'PASSPORT',
    documentNumber: 'SE-PASS-7782190',
  },
];

export const MIGRATION_BENCHMARKS: MigrationComparisonMetric[] = [
  {
    dimension: 'Core Architecture Paradigm',
    auraCore: 'Cloud-native event streaming with continuous sub-millisecond double-entry ledger balance',
    thoughtMachineVault: 'Microservices with Python smart contracts atop CockroachDB & Kafka',
    temenosTransact: 'Monolithic jBC (BASIC) legacy heritage ported to Java containers and relational DB',
    impactAdvantage: 'Zero legacy debt; continuous ACID consensus; 99.999% cloud availability',
  },
  {
    dimension: 'Product Launch Time-to-Market',
    auraCore: '48 to 72 hours via declarative smart contracts & real-time sandbox simulator',
    thoughtMachineVault: '1 to 2 weeks (Python contract testing & deployment pipeline)',
    temenosTransact: '6 to 9 months (proprietary T24 design studio & extensive core compilation)',
    impactAdvantage: '10x faster product release cycle without engineering vendor lock-in',
  },
  {
    dimension: 'Payment & ISO 20022 Native Model',
    auraCore: 'Native pacs.008 / pacs.002 data structures; direct FedNow, SEPA Inst, FPS routing',
    thoughtMachineVault: 'External payment hub required or partner integration layer (Form3 / Currencycloud)',
    temenosTransact: 'Payment adapter wrapper converting legacy SWIFT MT records to MX XML',
    impactAdvantage: 'Instantaneous multi-rail routing with native XML validation & zero translation lag',
  },
  {
    dimension: 'Posting Throughput & Latency',
    auraCore: '45,000+ continuous TPS at sub-5ms latency; zero-lock partition architecture',
    thoughtMachineVault: '15,000–25,000 TPS with distributed SQL overhead',
    temenosTransact: '3,000–8,000 TPS; relies on traditional overnight batch processing windows',
    impactAdvantage: 'No overnight batch shutdowns; true 24/7/365 real-time continuous accounting',
  },
  {
    dimension: 'Total Cost of Ownership (TCO)',
    auraCore: 'Scale-to-zero serverless & multi-cloud Kubernetes; 70% lower compute overhead',
    thoughtMachineVault: 'High infrastructure footprint requiring managed distributed database nodes',
    temenosTransact: 'Extensive on-prem/hybrid mainframe licensing and costly legacy consultants',
    impactAdvantage: 'Cuts infrastructure and vendor maintenance expenditure by 65–75%',
  },
];

export const INITIAL_SHADOW_RUN_TXS: ShadowRunTransaction[] = [
  {
    id: 'shw-801',
    description: 'BACS Payroll Direct Debit Sweep (Batch #490)',
    amount: 1450000.0,
    currency: 'GBP',
    legacyStatus: 'PROCESSING_BATCH',
    legacyLatencySeconds: 14400, // 4 hours in batch queue
    auraCoreStatus: 'SETTLED_REALTIME',
    auraCoreLatencyMs: 3.8,
    deltaMismatch: false,
  },
  {
    id: 'shw-802',
    description: 'FedNow Merchant Settlement (Point of Sale #881)',
    amount: 32450.0,
    currency: 'USD',
    legacyStatus: 'QUEUED',
    legacyLatencySeconds: 21600, // 6 hours waiting for end-of-day
    auraCoreStatus: 'SETTLED_REALTIME',
    auraCoreLatencyMs: 4.1,
    deltaMismatch: false,
  },
  {
    id: 'shw-803',
    description: 'High-Yield Savings Compound Interest Accrual',
    amount: 1985.45,
    currency: 'GBP',
    legacyStatus: 'COMPLETED_END_OF_DAY',
    legacyLatencySeconds: 28800, // 8 hour overnight batch
    auraCoreStatus: 'SETTLED_REALTIME',
    auraCoreLatencyMs: 2.9,
    deltaMismatch: false,
  },
  {
    id: 'shw-804',
    description: 'Cross-Border FX Spot Settlement EUR/USD',
    amount: 500000.0,
    currency: 'EUR',
    legacyStatus: 'PROCESSING_BATCH',
    legacyLatencySeconds: 7200,
    auraCoreStatus: 'SETTLED_REALTIME',
    auraCoreLatencyMs: 5.2,
    deltaMismatch: false,
  },
];
